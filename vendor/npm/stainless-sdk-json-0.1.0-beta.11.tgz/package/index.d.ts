import { Code } from '@pkg/plada/src/core';

declare type Operation =
  | AddOperation<any>
  | RemoveOperation
  | ReplaceOperation<any>
  | MoveOperation
  | CopyOperation
  | TestOperation<any>
  | GetOperation<any>;
interface BaseOperation {
  path: string;
}
interface AddOperation<T> extends BaseOperation {
  op: 'add';
  value: T;
}
interface RemoveOperation extends BaseOperation {
  op: 'remove';
}
interface ReplaceOperation<T> extends BaseOperation {
  op: 'replace';
  value: T;
}
interface MoveOperation extends BaseOperation {
  op: 'move';
  from: string;
}
interface CopyOperation extends BaseOperation {
  op: 'copy';
  from: string;
}
interface TestOperation<T> extends BaseOperation {
  op: 'test';
  value: T;
}
interface GetOperation<T> extends BaseOperation {
  op: '_get';
  value: T;
}

type Primitive$2 = null | undefined | string | number | boolean | symbol | bigint;
type BuiltIns = Primitive$2 | void | Date | RegExp;
type NonRecursiveType = BuiltIns | Function | (new (...arguments_: any[]) => unknown);
type SimplifyDeep<Type, ExcludeType = never> = ConditionalSimplifyDeep<
  Type,
  ExcludeType | NonRecursiveType | Set<unknown> | Map<unknown, unknown>,
  object
>;
type ConditionalSimplifyDeep<Type, ExcludeType = never, IncludeType = unknown> = Type extends ExcludeType
  ? Type
  : Type extends IncludeType
    ? {
        [TypeKey in keyof Type]: ConditionalSimplifyDeep<Type[TypeKey], ExcludeType, IncludeType>;
      }
    : Type;

type HeaderObject = ParameterBaseObject;
type ParameterBaseObject = {
  description?: string;
  required?: boolean;
  deprecated?: boolean;
  allowEmptyValue?: boolean;
  style?: string;
  explode?: boolean;
  allowReserved?: boolean;
  schema?: SchemaObject;
  example?: unknown;
  examples?: {
    [media: string]: ExampleObject;
  };
  content?: {
    [media: string]: MediaTypeObject;
  };
};
type PropertiesObject = {
  [name: string]: SchemaObject;
};
type SchemaListObject = Array</* ReferenceObject | */ SchemaObject>;
type SchemaPrimitiveType = 'null' | 'boolean' | 'number' | 'string' | 'integer';
type NonArraySchemaObjectType = SchemaPrimitiveType | 'object' | 'binary-response' | 'unknown';
type SchemaObjectType = NonArraySchemaObjectType | 'array';
interface SchemaObject {
  type?: SchemaObjectType | Array<SchemaObjectType>;
  title?: string;
  description?: string;
  format?: string;
  default?: any;
  multipleOf?: number;
  maximum?: number;
  exclusiveMaximum?: boolean | number;
  minimum?: number;
  exclusiveMinimum?: boolean | number;
  maxLength?: number;
  minLength?: number;
  pattern?: string;
  additionalProperties?: boolean | /* ReferenceObject | */ SchemaObject;
  maxItems?: number;
  minItems?: number;
  uniqueItems?: boolean;
  maxProperties?: number;
  minProperties?: number;
  required?: string[];
  enum?: unknown[];
  const?: any;
  properties?: PropertiesObject;
  allOf?: SchemaListObject;
  anyOf?: SchemaListObject;
  oneOf?: SchemaListObject;
  items?: SchemaObject;
  nullable?: boolean;
  discriminator?: DiscriminatorObject;
  readOnly?: boolean;
  writeOnly?: boolean;
  example?: any;
  examples?: any[];
  deprecated?: boolean;
  $ref?: string;
  [key: `x-${string}`]: unknown;
  [key: `_x-${string}`]: unknown;
}
type DiscriminatorObject = {
  propertyName: string;
  mapping?: {
    [value: string]: string;
  };
};
type ExampleObject = {
  summary?: string;
  description?: string;
  value?: unknown;
  externalValue?: string;
};
type EncodingsObject = {
  [media: string]: EncodingObject;
};
interface MediaTypeObject {
  schema?: SchemaObject;
  nullable?: boolean;
  example?: any;
  examples?: {
    [media: string]: ExampleObject;
  };
  encoding?: EncodingsObject;
}
type EncodingObject = {
  contentType?: string;
  headers?: HeadersObject;
  style?: string;
  explode?: boolean;
  allowReserved?: boolean;
};
type ResponseContentObject = {
  [media: string]: MediaTypeObject;
};
type HeadersObject = {
  [key: string]: HeaderObject;
};

type HTTPMethod = 'get' | 'post' | 'put' | 'patch' | 'delete' | 'query';
type SupportedLanguage =
  | 'node'
  | 'typescript'
  | 'python'
  | 'go'
  | 'java'
  | 'kotlin'
  | 'ruby'
  | 'terraform'
  | 'cli'
  | 'php'
  | 'csharp'
  | 'sql'
  | 'http'
  | 'openapi';
interface Config {
  docs:
    | {
        title?: string | undefined;
        favicon?: string | undefined;
        logo_icon?: string | undefined;
        search?:
          | {
              algolia?:
                | {
                    app_id: string;
                    index_name: string;
                    search_key: string;
                  }
                | undefined;
            }
          | undefined;
        description?: string | undefined;
        languages?: SupportedLanguage[] | undefined;
        snippets?:
          | {
              exclude_languages?: string[] | undefined;
            }
          | undefined;
        show_security?: boolean | undefined;
        show_readme?: boolean | undefined;
        base_path?: string | undefined;
        navigation?: unknown;
        pages?: Record<string, string> | undefined;
        resources?:
          | {
              title: string;
              children: string[];
            }[]
          | undefined;
      }
    | undefined;
}

type InternalDiagnosticLevel =
  | 'fatal'
  | 'user_generated_fatal'
  | 'internal_error'
  | 'error'
  | 'warning'
  | 'note';
type DiagnosticLevel = Exclude<InternalDiagnosticLevel, 'user_generated_fatal' | 'internal_error'>;
type AutoFixOp = SimplifyDeep<
  {
    file: 'config';
  } & Operation
>;
type DiagnosticInfo = {
  code: string;
  level: InternalDiagnosticLevel;
  ignored: boolean;
  message: string;
  messageHtml: string;
  more:
    | string
    | {
        raw: string;
      }
    | null;
  link: string;
  endpoint: string | null;
  language: SupportedLanguage | null;
  customer: string | null;
  location: string | null;
  stainlessPath: string | null;
  oasRef: string | null;
  configRef: string | null;
  autoFixPlan: AutoFixOp[] | null;
  trace?: string;
};
type DiagnosticExport = DiagnosticInfo & {
  level: DiagnosticLevel;
};

type SDKSchemaReference = never;
type SDKSchema = never;
type SDKSchemaType = string;
type SDKPropertySchemaReference<T = never> = never;

type HttpDeclaration =
  | HttpDeclFunction
  | HttpDeclProperty
  | HttpDeclTypeAlias
  | HttpDeclReference
  | ErrorDecl;
type HttpDeclFunction = BaseDeclaration & {
  kind: 'HttpDeclFunction';
  ident: HttpIdentifier;
  qualified?: string;
  returns?: HttpType;
  paramsChildren?: Record<string, ID[]>;
  bodyParamsChildren?: Record<string, ID[]>;
  responseChildren?: ID[];
};
type HttpDeclProperty = BaseDeclaration & {
  kind: 'HttpDeclProperty';
  key: string;
  docstring?: string;
  title?: string;
  location?: string;
  type: HttpType;
  constraints?: Constraints;
  default?: unknown;
  examples?: unknown[];
  optional?: boolean;
  nullable?: boolean;
  declare?: boolean;
  schemaType?: SchemaType;
  modelPath?: string;
  childrenParentSchema?: SchemaType;
  children?: ID[];
};
type HttpDeclTypeAlias = BaseDeclaration & {
  kind: 'HttpDeclTypeAlias';
  docstring?: string;
  ident: HttpIdentifier;
  typeParameters?: HttpTypeParameter[];
  type: HttpType;
  children?: ID[];
};
type HttpTypeParameter = {
  kind: 'HttpTypeParameter';
  name: HttpIdentifier;
  constraint?: HttpType;
  default?: HttpType;
};
type HttpIdentifier = string;
type HttpDeclReference = BaseDeclaration & {
  kind: 'HttpDeclReference';
  docstring?: string;
  type: HttpType;
  children?: ID[];
};
type HttpType =
  | HttpTypeReference
  | HttpTypeObject
  | HttpTypeArray
  | HttpTypeString
  | HttpTypeNumber
  | HttpTypeBoolean
  | HttpTypeNull
  | HttpTypeUndefined
  | HttpTypeBinary
  | HttpTypeUnknown
  | HttpTypeLiteral
  | HttpTypeUnion
  | HttpTypeIntersection;
type HttpTypeReference = BaseType & {
  kind: 'HttpTypeReference';
  ident: HttpIdentifier;
  typeParameters?: HttpType[];
  $ref?: ID;
};
type HttpTypeObject = BaseType & {
  kind: 'HttpTypeObject';
  members: {
    ident: HttpIdentifier;
    optional?: boolean;
  }[];
};
type HttpTypeArray = BaseType & {
  kind: 'HttpTypeArray';
  elementType: HttpType;
};
type HttpTypeUnion = BaseType & {
  kind: 'HttpTypeUnion';
  types: HttpType[];
};
type HttpTypeIntersection = BaseType & {
  kind: 'HttpTypeIntersection';
  types: HttpType[];
};
type HttpTypeLiteral = BaseType & {
  kind: 'HttpTypeLiteral';
  literal: string | boolean | number;
};
type HttpTypeString = BaseType & {
  kind: 'HttpTypeString';
};
type HttpTypeNumber = BaseType & {
  kind: 'HttpTypeNumber';
};
type HttpTypeBoolean = BaseType & {
  kind: 'HttpTypeBoolean';
};
type HttpTypeNull = BaseType & {
  kind: 'HttpTypeNull';
};
type HttpTypeUndefined = BaseType & {
  kind: 'HttpTypeUndefined';
};
type HttpTypeBinary = BaseType & {
  kind: 'HttpTypeBinary';
  contentType: string[];
};
type HttpTypeUnknown = BaseType & {
  kind: 'HttpTypeUnknown';
};

type HttpAST_HttpDeclFunction = HttpDeclFunction;
type HttpAST_HttpDeclProperty = HttpDeclProperty;
type HttpAST_HttpDeclReference = HttpDeclReference;
type HttpAST_HttpDeclTypeAlias = HttpDeclTypeAlias;
type HttpAST_HttpDeclaration = HttpDeclaration;
type HttpAST_HttpIdentifier = HttpIdentifier;
type HttpAST_HttpType = HttpType;
type HttpAST_HttpTypeArray = HttpTypeArray;
type HttpAST_HttpTypeBinary = HttpTypeBinary;
type HttpAST_HttpTypeBoolean = HttpTypeBoolean;
type HttpAST_HttpTypeIntersection = HttpTypeIntersection;
type HttpAST_HttpTypeLiteral = HttpTypeLiteral;
type HttpAST_HttpTypeNull = HttpTypeNull;
type HttpAST_HttpTypeNumber = HttpTypeNumber;
type HttpAST_HttpTypeObject = HttpTypeObject;
type HttpAST_HttpTypeParameter = HttpTypeParameter;
type HttpAST_HttpTypeReference = HttpTypeReference;
type HttpAST_HttpTypeString = HttpTypeString;
type HttpAST_HttpTypeUndefined = HttpTypeUndefined;
type HttpAST_HttpTypeUnion = HttpTypeUnion;
type HttpAST_HttpTypeUnknown = HttpTypeUnknown;
declare namespace HttpAST {
  export type {
    HttpAST_HttpDeclFunction as HttpDeclFunction,
    HttpAST_HttpDeclProperty as HttpDeclProperty,
    HttpAST_HttpDeclReference as HttpDeclReference,
    HttpAST_HttpDeclTypeAlias as HttpDeclTypeAlias,
    HttpAST_HttpDeclaration as HttpDeclaration,
    HttpAST_HttpIdentifier as HttpIdentifier,
    HttpAST_HttpType as HttpType,
    HttpAST_HttpTypeArray as HttpTypeArray,
    HttpAST_HttpTypeBinary as HttpTypeBinary,
    HttpAST_HttpTypeBoolean as HttpTypeBoolean,
    HttpAST_HttpTypeIntersection as HttpTypeIntersection,
    HttpAST_HttpTypeLiteral as HttpTypeLiteral,
    HttpAST_HttpTypeNull as HttpTypeNull,
    HttpAST_HttpTypeNumber as HttpTypeNumber,
    HttpAST_HttpTypeObject as HttpTypeObject,
    HttpAST_HttpTypeParameter as HttpTypeParameter,
    HttpAST_HttpTypeReference as HttpTypeReference,
    HttpAST_HttpTypeString as HttpTypeString,
    HttpAST_HttpTypeUndefined as HttpTypeUndefined,
    HttpAST_HttpTypeUnion as HttpTypeUnion,
    HttpAST_HttpTypeUnknown as HttpTypeUnknown,
  };
}

/**
 * Base declaration types for CLI command AST
 */
type CLIDeclaration = CLICommand | CLIFlag | CLISchemaProperty | CLIStdin | CLIFunction | ErrorDecl;
/**
 * Represents a command in a CLI environment
 */
type CLICommand = BaseDeclaration & {
  kind: 'CLICommand';
  invocation: string[];
  name: string;
  arguments?: CLIArgument[];
  options?: CLIFlag[];
  stdin?: CLIStdin;
  background?: boolean;
  subshell?: boolean;
  workingDir?: string;
  children?: ID[];
  paramsChildren?: ID[];
  responseChildren?: ID[];
  ident: string;
  qualified?: string;
  docstring?: string;
  parameters?: unknown[];
  responseType?: HttpType;
};
/**
 * Represents a command argument
 */
type CLIArgument = {
  kind: 'CLIArgument';
  value: string;
  quoted?: boolean;
  docstring?: string;
  quoteType?: 'single' | 'double' | 'backtick';
};
/**
 * Represents a command line flag --foo
 */
type CLIFlag = BaseDeclaration & {
  kind: 'CLIFlag';
  name?: string;
  enabled?: boolean;
  ident: string;
  flag?:
    | string
    | {
        name: string;
      };
  title?: string;
  docstring?: string;
  optional?: boolean;
  type?: HttpType;
  constraints?: unknown;
  schemaType?: string;
  modelPath?: string;
  childrenParentSchema?: unknown;
  children?: ID[];
};
/**
 * Represents a CLI property (for return values/response fields)
 */
type CLISchemaProperty = BaseDeclaration & {
  kind: 'CLISchemaProperty';
  name: string;
  ident: string;
  type?: HttpType;
  docstring?: string;
  optional?: boolean;
  constraints?: unknown;
  schemaType?: string;
  children?: ID[];
  childrenParentSchema?: unknown;
};
/**
 * Represents data piped in to stdin
 */
type CLIStdin = BaseDeclaration & {
  kind: 'CLIStdin';
  text: string;
};
/**
 * Represents a shell function
 */
type CLIFunction = BaseDeclaration & {
  kind: 'CLIFunction';
  name: string;
  body: CLICommand[];
  parameters?: string[];
  description?: string;
  docstring?: string;
  children?: ID[];
};

type CLIAST_CLIArgument = CLIArgument;
type CLIAST_CLICommand = CLICommand;
type CLIAST_CLIDeclaration = CLIDeclaration;
type CLIAST_CLIFlag = CLIFlag;
type CLIAST_CLIFunction = CLIFunction;
type CLIAST_CLISchemaProperty = CLISchemaProperty;
type CLIAST_CLIStdin = CLIStdin;
declare namespace CLIAST {
  export type {
    CLIAST_CLIArgument as CLIArgument,
    CLIAST_CLICommand as CLICommand,
    CLIAST_CLIDeclaration as CLIDeclaration,
    CLIAST_CLIFlag as CLIFlag,
    CLIAST_CLIFunction as CLIFunction,
    CLIAST_CLISchemaProperty as CLISchemaProperty,
    CLIAST_CLIStdin as CLIStdin,
  };
}

type CSharpDeclaration =
  | CSharpDeclFunction
  | CSharpDeclType
  | CSharpDeclProperty
  | CSharpDeclConst
  | CSharpDeclReference
  | ErrorDecl;
type CSharpDeclFunction = BaseDeclaration & {
  kind: 'CSharpDeclFunction';
  ident: CSharpIdentifier;
  qualified?: string;
  docstring?: string;
  async?: boolean;
  parameters: CSharpFunctionParameter[];
  returnType?: CSharpType;
  paramsChildren?: ID[];
  responseChildren?: ID[];
};
type CSharpFunctionParameter = {
  kind: 'CSharpFunctionParameter';
  ident: CSharpIdentifier;
  typeAnnotation: CSharpType;
  hasDefault: boolean;
};
type CSharpDeclType = BaseDeclaration & {
  kind: 'CSharpDeclType';
  docstring?: string;
  ident: CSharpIdentifier;
  type: CSharpType;
  children?: ID[];
};
type CSharpIdentifier = string;
type CSharpDeclProperty = BaseDeclaration & {
  kind: 'CSharpDeclProperty';
  docstring?: string;
  title?: string;
  ident: CSharpIdentifier;
  type: CSharpType;
  optional?: boolean;
  nullable?: boolean;
  examples?: unknown[];
  schemaType?: SchemaType;
  modelPath?: string;
  childrenParentSchema?: SchemaType;
  children?: ID[];
};
type CSharpDeclConst = BaseDeclaration & {
  kind: 'CSharpDeclConst';
  docstring?: string;
  ident: CSharpIdentifier;
  type: CSharpType;
  value: boolean | string | number;
};
type CSharpDeclReference = BaseDeclaration & {
  kind: 'CSharpDeclReference';
  docstring?: string;
  type: CSharpType;
  schemaType?: SchemaType;
  children?: ID[];
};
type CSharpType =
  | CSharpTypeReference
  | CSharpTypeClass
  | CSharpTypeUnion
  | CSharpTypeEnum
  | CSharpTypeBoolean
  | CSharpTypeFloat
  | CSharpTypeDouble
  | CSharpTypeInt
  | CSharpTypeLong
  | CSharpTypeString
  | CSharpTypeConstant;
type CSharpTypeReference = BaseType & {
  kind: 'CSharpTypeReference';
  typeName: CSharpIdentifier;
  typeParameters?: CSharpType[];
  nullable?: boolean;
  $ref?: string;
};
type CSharpTypeClass = BaseType & {
  kind: 'CSharpTypeClass';
};
type CSharpTypeUnion = BaseType & {
  kind: 'CSharpTypeUnion';
};
type CSharpTypeEnum = BaseType & {
  kind: 'CSharpTypeEnum';
};
type CSharpTypeBoolean = BaseType & {
  kind: 'CSharpTypeBoolean';
};
type CSharpTypeFloat = BaseType & {
  kind: 'CSharpTypeFloat';
};
type CSharpTypeDouble = BaseType & {
  kind: 'CSharpTypeDouble';
};
type CSharpTypeInt = BaseType & {
  kind: 'CSharpTypeInt';
};
type CSharpTypeLong = BaseType & {
  kind: 'CSharpTypeLong';
};
type CSharpTypeString = BaseType & {
  kind: 'CSharpTypeString';
};
type CSharpTypeConstant = BaseType & {
  kind: 'CSharpTypeConstant';
  value: string;
};

type CSharpAST_CSharpDeclConst = CSharpDeclConst;
type CSharpAST_CSharpDeclFunction = CSharpDeclFunction;
type CSharpAST_CSharpDeclProperty = CSharpDeclProperty;
type CSharpAST_CSharpDeclReference = CSharpDeclReference;
type CSharpAST_CSharpDeclType = CSharpDeclType;
type CSharpAST_CSharpDeclaration = CSharpDeclaration;
type CSharpAST_CSharpFunctionParameter = CSharpFunctionParameter;
type CSharpAST_CSharpIdentifier = CSharpIdentifier;
type CSharpAST_CSharpType = CSharpType;
type CSharpAST_CSharpTypeBoolean = CSharpTypeBoolean;
type CSharpAST_CSharpTypeClass = CSharpTypeClass;
type CSharpAST_CSharpTypeConstant = CSharpTypeConstant;
type CSharpAST_CSharpTypeDouble = CSharpTypeDouble;
type CSharpAST_CSharpTypeEnum = CSharpTypeEnum;
type CSharpAST_CSharpTypeFloat = CSharpTypeFloat;
type CSharpAST_CSharpTypeInt = CSharpTypeInt;
type CSharpAST_CSharpTypeLong = CSharpTypeLong;
type CSharpAST_CSharpTypeReference = CSharpTypeReference;
type CSharpAST_CSharpTypeString = CSharpTypeString;
type CSharpAST_CSharpTypeUnion = CSharpTypeUnion;
declare namespace CSharpAST {
  export type {
    CSharpAST_CSharpDeclConst as CSharpDeclConst,
    CSharpAST_CSharpDeclFunction as CSharpDeclFunction,
    CSharpAST_CSharpDeclProperty as CSharpDeclProperty,
    CSharpAST_CSharpDeclReference as CSharpDeclReference,
    CSharpAST_CSharpDeclType as CSharpDeclType,
    CSharpAST_CSharpDeclaration as CSharpDeclaration,
    CSharpAST_CSharpFunctionParameter as CSharpFunctionParameter,
    CSharpAST_CSharpIdentifier as CSharpIdentifier,
    CSharpAST_CSharpType as CSharpType,
    CSharpAST_CSharpTypeBoolean as CSharpTypeBoolean,
    CSharpAST_CSharpTypeClass as CSharpTypeClass,
    CSharpAST_CSharpTypeConstant as CSharpTypeConstant,
    CSharpAST_CSharpTypeDouble as CSharpTypeDouble,
    CSharpAST_CSharpTypeEnum as CSharpTypeEnum,
    CSharpAST_CSharpTypeFloat as CSharpTypeFloat,
    CSharpAST_CSharpTypeInt as CSharpTypeInt,
    CSharpAST_CSharpTypeLong as CSharpTypeLong,
    CSharpAST_CSharpTypeReference as CSharpTypeReference,
    CSharpAST_CSharpTypeString as CSharpTypeString,
    CSharpAST_CSharpTypeUnion as CSharpTypeUnion,
  };
}

type JavaDeclaration =
  | JavaDeclFunction
  | JavaDeclType
  | JavaDeclProperty
  | JavaDeclConst
  | JavaDeclReference
  | ErrorDecl;
type JavaDeclFunction = BaseDeclaration & {
  kind: 'JavaDeclFunction';
  ident: JavaIdentifier;
  qualified?: string;
  docstring?: string;
  async?: boolean;
  parameters: JavaFunctionParameter[];
  returnType?: JavaType;
  paramsChildren?: ID[];
  responseChildren?: ID[];
};
type JavaFunctionParameter = {
  kind: 'JavaFunctionParameter';
  ident: JavaIdentifier;
  typeAnnotation: JavaType;
  hasDefault: boolean;
};
type JavaDeclType = BaseDeclaration & {
  kind: 'JavaDeclType';
  docstring?: string;
  ident: JavaIdentifier;
  type: JavaType;
  children?: ID[];
};
type JavaIdentifier = string;
type JavaDeclProperty = BaseDeclaration & {
  kind: 'JavaDeclProperty';
  docstring?: string;
  title?: string;
  ident: JavaIdentifier;
  type: JavaType;
  optional?: boolean;
  examples?: unknown[];
  schemaType?: SchemaType;
  modelPath?: string;
  childrenParentSchema?: SchemaType;
  children?: ID[];
};
type JavaDeclConst = BaseDeclaration & {
  kind: 'JavaDeclConst';
  docstring?: string;
  ident: JavaIdentifier;
  type: JavaType;
  value: boolean | string | number;
};
type JavaDeclReference = BaseDeclaration & {
  kind: 'JavaDeclReference';
  docstring?: string;
  type: JavaType;
  schemaType?: SchemaType;
  children?: ID[];
};
type JavaType =
  | JavaTypeReference
  | JavaTypeClass
  | JavaTypeUnion
  | JavaTypeEnum
  | JavaTypeVoid
  | JavaTypeBoolean
  | JavaTypeDouble
  | JavaTypeLong
  | JavaTypeString
  | JavaTypeConstant;
type JavaTypeReference = BaseType & {
  kind: 'JavaTypeReference';
  typeName: JavaIdentifier;
  typeParameters?: JavaType[];
  $ref?: string;
};
type JavaTypeClass = BaseType & {
  kind: 'JavaTypeClass';
};
type JavaTypeUnion = BaseType & {
  kind: 'JavaTypeUnion';
};
type JavaTypeEnum = BaseType & {
  kind: 'JavaTypeEnum';
};
type JavaTypeVoid = BaseType & {
  kind: 'JavaTypeVoid';
};
type JavaTypeBoolean = BaseType & {
  kind: 'JavaTypeBoolean';
};
type JavaTypeDouble = BaseType & {
  kind: 'JavaTypeDouble';
};
type JavaTypeLong = BaseType & {
  kind: 'JavaTypeLong';
};
type JavaTypeString = BaseType & {
  kind: 'JavaTypeString';
};
type JavaTypeConstant = BaseType & {
  kind: 'JavaTypeConstant';
  value: string;
};

type JavaAST_JavaDeclConst = JavaDeclConst;
type JavaAST_JavaDeclFunction = JavaDeclFunction;
type JavaAST_JavaDeclProperty = JavaDeclProperty;
type JavaAST_JavaDeclReference = JavaDeclReference;
type JavaAST_JavaDeclType = JavaDeclType;
type JavaAST_JavaDeclaration = JavaDeclaration;
type JavaAST_JavaFunctionParameter = JavaFunctionParameter;
type JavaAST_JavaIdentifier = JavaIdentifier;
type JavaAST_JavaType = JavaType;
type JavaAST_JavaTypeBoolean = JavaTypeBoolean;
type JavaAST_JavaTypeClass = JavaTypeClass;
type JavaAST_JavaTypeConstant = JavaTypeConstant;
type JavaAST_JavaTypeDouble = JavaTypeDouble;
type JavaAST_JavaTypeEnum = JavaTypeEnum;
type JavaAST_JavaTypeLong = JavaTypeLong;
type JavaAST_JavaTypeReference = JavaTypeReference;
type JavaAST_JavaTypeString = JavaTypeString;
type JavaAST_JavaTypeUnion = JavaTypeUnion;
type JavaAST_JavaTypeVoid = JavaTypeVoid;
declare namespace JavaAST {
  export type {
    JavaAST_JavaDeclConst as JavaDeclConst,
    JavaAST_JavaDeclFunction as JavaDeclFunction,
    JavaAST_JavaDeclProperty as JavaDeclProperty,
    JavaAST_JavaDeclReference as JavaDeclReference,
    JavaAST_JavaDeclType as JavaDeclType,
    JavaAST_JavaDeclaration as JavaDeclaration,
    JavaAST_JavaFunctionParameter as JavaFunctionParameter,
    JavaAST_JavaIdentifier as JavaIdentifier,
    JavaAST_JavaType as JavaType,
    JavaAST_JavaTypeBoolean as JavaTypeBoolean,
    JavaAST_JavaTypeClass as JavaTypeClass,
    JavaAST_JavaTypeConstant as JavaTypeConstant,
    JavaAST_JavaTypeDouble as JavaTypeDouble,
    JavaAST_JavaTypeEnum as JavaTypeEnum,
    JavaAST_JavaTypeLong as JavaTypeLong,
    JavaAST_JavaTypeReference as JavaTypeReference,
    JavaAST_JavaTypeString as JavaTypeString,
    JavaAST_JavaTypeUnion as JavaTypeUnion,
    JavaAST_JavaTypeVoid as JavaTypeVoid,
  };
}

type PhpIdentifier = string;
type PhpDeclaration =
  | PhpDeclMethod
  | PhpDeclParam
  | PhpDeclClass
  | PhpDeclClassProperty
  | PhpDeclAssocArray
  | PhpDeclAssocArrayProperty
  | PhpDeclEnum
  | PhpDeclReference
  | ErrorDecl;
type PhpDeclMethod = BaseDeclaration & {
  kind: 'PhpDeclMethod';
  ident: PhpIdentifier;
  parameters: PhpMethodParameter[];
  returnType?: PhpType;
  qualified?: string;
  docstring?: string;
  paramsChildren?: ID[];
  responseChildren?: ID[];
};
type PhpMethodParameter = {
  kind: 'PhpMethodParameter';
  ident: PhpIdentifier;
  typeAnnotation: PhpType;
  optional: boolean;
  hasDefault?: boolean;
};
type PhpMethodDeclParameter = BaseDeclaration & {
  kind: 'PhpMethodDeclParameter';
  ident: PhpIdentifier;
  typeAnnotation: PhpType;
  hasDefault?: boolean;
};
type PhpDeclReference = BaseDeclaration & {
  kind: 'PhpDeclReference';
  docstring?: string;
  type: PhpType;
  scope?: 'class' | '@phpstan-type';
  children?: ID[];
};
type PhpDeclParam = BaseDeclaration & {
  kind: 'PhpDeclParam';
  ident: PhpIdentifier;
  type: PhpType;
  optional: boolean;
  isPositional: boolean;
  default?: unknown;
  examples?: unknown[];
  oasRef?: string;
  modelPath?: string;
  docstring?: string;
  deprecated?: string | boolean;
  children?: ID[];
};
/** For PHPStan array definitions. */
type PhpDeclAssocArrayProperty = BaseDeclaration & {
  kind: 'PhpDeclAssocArrayProperty';
  ident: PhpIdentifier;
  type: PhpType;
  optional: boolean;
  oasRef?: string;
  modelPath?: string;
  docstring?: string;
  deprecated?: string | boolean;
  children?: ID[];
};
type PhpDeclClassProperty = BaseDeclaration & {
  kind: 'PhpDeclClassProperty';
  ident: PhpIdentifier;
  type: PhpType;
  nullable: boolean;
  docstring?: string;
  default?: string;
  examples?: unknown[];
  deprecated?: string | boolean;
  modelPath?: string;
  children?: ID[];
};
type PhpDeclEnum = BaseDeclaration & {
  kind: 'PhpDeclEnum';
  ident: PhpIdentifier;
  members: {
    case: PhpIdentifier;
    backingType?: 'string' | 'int';
    value?: string | number;
  }[];
};
type PhpDeclClass = BaseDeclaration & {
  kind: 'PhpDeclClass';
  ident: PhpIdentifier;
  docstring?: string;
  children?: ID[];
};
type PhpDeclAssocArray = BaseDeclaration & {
  kind: 'PhpDeclAssocArray';
  ident: PhpIdentifier;
  type: PhpType;
  children?: ID[];
};
type PhpType = SDKJSONPhpType<string>;
type SDKJSONPhpIdentifier<T extends Code = string> = T;
type SDKJSONPhpType<T extends Code = string> =
  | PhpTypeReference<T>
  | PhpTypeMapArray<T>
  | PhpTypeListArray<T>
  | PhpTypeUnion<T>
  | PhpTypeLiteral
  | PhpTypeString
  | PhpTypeFloat
  | PhpTypeInt
  | PhpTypeBool
  | PhpTypeNull
  | PhpTypeMixed
  | PhpTypeDatetime
  | PhpTypeComplexBuiltin;
type PhpTypeReference<T extends Code = string> = BaseType & {
  kind: 'PhpTypeReference';
  typeName: SDKJSONPhpIdentifier<T>;
  $ref?: ID | string;
  typeParameters?: PhpType[];
};
type PhpTypeMapArray<T extends Code = string> = BaseType & {
  kind: 'PhpTypeMapArray';
  elementType: SDKJSONPhpType<T>;
};
type PhpTypeListArray<T extends Code = string> = BaseType & {
  kind: 'PhpTypeListArray';
  elementType: SDKJSONPhpType<T>;
};
type PhpTypeUnion<T extends Code = string> = BaseType & {
  kind: 'PhpTypeUnion';
  types: SDKJSONPhpType<T>[];
};
type PhpTypeLiteral = BaseType & {
  kind: 'PhpTypeLiteral';
  literal: string | boolean | number;
};
type PhpTypeString = BaseType & {
  kind: 'PhpTypeString';
};
type PhpTypeFloat = BaseType & {
  kind: 'PhpTypeFloat';
};
type PhpTypeInt = BaseType & {
  kind: 'PhpTypeInt';
};
type PhpTypeBool = BaseType & {
  kind: 'PhpTypeBool';
};
type PhpTypeNull = BaseType & {
  kind: 'PhpTypeNull';
};
type PhpTypeMixed = BaseType & {
  kind: 'PhpTypeMixed';
};
type PhpTypeDatetime = BaseType & {
  kind: 'PhpTypeDatetime';
};
type PhpTypeComplexBuiltin = BaseType & {
  kind: 'PhpTypeComplexBuiltin';
  typeName: 'resource' | 'callable' | 'class-string' | 'array' | 'object';
};

type PhpAST_PhpDeclAssocArray = PhpDeclAssocArray;
type PhpAST_PhpDeclAssocArrayProperty = PhpDeclAssocArrayProperty;
type PhpAST_PhpDeclClass = PhpDeclClass;
type PhpAST_PhpDeclClassProperty = PhpDeclClassProperty;
type PhpAST_PhpDeclEnum = PhpDeclEnum;
type PhpAST_PhpDeclMethod = PhpDeclMethod;
type PhpAST_PhpDeclParam = PhpDeclParam;
type PhpAST_PhpDeclReference = PhpDeclReference;
type PhpAST_PhpDeclaration = PhpDeclaration;
type PhpAST_PhpMethodDeclParameter = PhpMethodDeclParameter;
type PhpAST_PhpMethodParameter = PhpMethodParameter;
type PhpAST_PhpType = PhpType;
type PhpAST_PhpTypeBool = PhpTypeBool;
type PhpAST_PhpTypeComplexBuiltin = PhpTypeComplexBuiltin;
type PhpAST_PhpTypeDatetime = PhpTypeDatetime;
type PhpAST_PhpTypeFloat = PhpTypeFloat;
type PhpAST_PhpTypeInt = PhpTypeInt;
type PhpAST_PhpTypeListArray<T extends Code = string> = PhpTypeListArray<T>;
type PhpAST_PhpTypeLiteral = PhpTypeLiteral;
type PhpAST_PhpTypeMapArray<T extends Code = string> = PhpTypeMapArray<T>;
type PhpAST_PhpTypeMixed = PhpTypeMixed;
type PhpAST_PhpTypeNull = PhpTypeNull;
type PhpAST_PhpTypeReference<T extends Code = string> = PhpTypeReference<T>;
type PhpAST_PhpTypeString = PhpTypeString;
type PhpAST_PhpTypeUnion<T extends Code = string> = PhpTypeUnion<T>;
type PhpAST_SDKJSONPhpType<T extends Code = string> = SDKJSONPhpType<T>;
declare namespace PhpAST {
  export type {
    PhpAST_PhpDeclAssocArray as PhpDeclAssocArray,
    PhpAST_PhpDeclAssocArrayProperty as PhpDeclAssocArrayProperty,
    PhpAST_PhpDeclClass as PhpDeclClass,
    PhpAST_PhpDeclClassProperty as PhpDeclClassProperty,
    PhpAST_PhpDeclEnum as PhpDeclEnum,
    PhpAST_PhpDeclMethod as PhpDeclMethod,
    PhpAST_PhpDeclParam as PhpDeclParam,
    PhpAST_PhpDeclReference as PhpDeclReference,
    PhpAST_PhpDeclaration as PhpDeclaration,
    PhpAST_PhpMethodDeclParameter as PhpMethodDeclParameter,
    PhpAST_PhpMethodParameter as PhpMethodParameter,
    PhpAST_PhpType as PhpType,
    PhpAST_PhpTypeBool as PhpTypeBool,
    PhpAST_PhpTypeComplexBuiltin as PhpTypeComplexBuiltin,
    PhpAST_PhpTypeDatetime as PhpTypeDatetime,
    PhpAST_PhpTypeFloat as PhpTypeFloat,
    PhpAST_PhpTypeInt as PhpTypeInt,
    PhpAST_PhpTypeListArray as PhpTypeListArray,
    PhpAST_PhpTypeLiteral as PhpTypeLiteral,
    PhpAST_PhpTypeMapArray as PhpTypeMapArray,
    PhpAST_PhpTypeMixed as PhpTypeMixed,
    PhpAST_PhpTypeNull as PhpTypeNull,
    PhpAST_PhpTypeReference as PhpTypeReference,
    PhpAST_PhpTypeString as PhpTypeString,
    PhpAST_PhpTypeUnion as PhpTypeUnion,
    PhpAST_SDKJSONPhpType as SDKJSONPhpType,
  };
}

type PythonDeclaration =
  | PythonDeclFunction
  | PythonDeclClass
  | PythonDeclType
  | PythonDeclProperty
  | PythonDeclReference
  | ErrorDecl;
type PythonDeclFunction = BaseDeclaration & {
  kind: 'PythonDeclFunction';
  ident: PythonIdentifier;
  qualified?: string;
  docstring?: string;
  async?: boolean;
  generics?: PythonGenericParameter[];
  parameters: PythonFunctionParameter[];
  returns?: PythonType;
  paramsChildren?: ID[];
  responseChildren?: ID[];
};
type PythonFunctionParameter = {
  kind: 'PythonFunctionParameter';
  ident: PythonIdentifier;
  type: PythonType;
  optional?: boolean;
};
type PythonGenericParameter = {
  kind: 'PythonTypeParameter';
  name: string;
  constraint?: PythonType;
};
type PythonDeclClass = BaseDeclaration & {
  kind: 'PythonDeclClass';
  docstring?: string;
  ident: PythonIdentifier;
  generics?: PythonGenericParameter[];
  children?: ID[];
};
type PythonDeclType = BaseDeclaration & {
  kind: 'PythonDeclType';
  docstring?: string;
  ident: PythonIdentifier;
  generics?: PythonGenericParameter[];
  type: PythonType;
  childrenParentSchema?: SchemaType;
  children?: ID[];
};
type PythonIdentifier = string;
type PythonLiteral = {
  kind: 'PythonLiteral';
  value: string | number | boolean;
};
type PythonDeclProperty = BaseDeclaration & {
  kind: 'PythonDeclProperty';
  docstring?: string;
  title?: string;
  ident: PythonIdentifier;
  type: PythonType;
  constraints?: Constraints;
  optional?: boolean;
  default?: unknown;
  examples?: unknown[];
  schemaType?: SchemaType;
  modelPath?: string;
  childrenParentSchema?: SchemaType;
  children?: ID[];
};
type PythonDeclReference = BaseDeclaration & {
  kind: 'PythonDeclReference';
  docstring?: string;
  type: PythonType;
  children?: ID[];
};
type PythonType =
  | PythonTypeReference
  | PythonTypeClass
  | PythonTypeArray
  | PythonTypeMap
  | PythonTypeString
  | PythonTypeFloat
  | PythonTypeInt
  | PythonTypeBool
  | PythonTypeAny
  | PythonTypeUnknown
  | PythonTypeLiteral;
type PythonTypeReference = BaseType & {
  kind: 'PythonTypeReference';
  typeName: PythonIdentifier;
  typeParameters?: PythonType[];
  schemaType?: SchemaType;
  $ref?: string;
};
type PythonTypeClass = BaseType & {
  kind: 'PythonTypeClass';
  body: {
    ident: PythonIdentifier;
    type: PythonType;
  }[];
};
type PythonTypeArray = BaseType & {
  kind: 'PythonTypeArray';
  elementType: PythonType;
};
type PythonTypeMap = BaseType & {
  kind: 'PythonTypeMap';
  indexType: PythonType;
  itemType: PythonType;
};
type PythonTypeString = BaseType & {
  kind: 'PythonTypeString';
};
type PythonTypeFloat = BaseType & {
  kind: 'PythonTypeFloat';
};
type PythonTypeInt = BaseType & {
  kind: 'PythonTypeInt';
};
type PythonTypeBool = BaseType & {
  kind: 'PythonTypeBool';
};
type PythonTypeAny = BaseType & {
  kind: 'PythonTypeAny';
};
type PythonTypeUnknown = BaseType & {
  kind: 'PythonTypeUnknown';
};
type PythonTypeLiteral = BaseType & {
  kind: 'PythonTypeLiteral';
  literal: PythonLiteral;
};

type PythonAST_PythonDeclClass = PythonDeclClass;
type PythonAST_PythonDeclFunction = PythonDeclFunction;
type PythonAST_PythonDeclProperty = PythonDeclProperty;
type PythonAST_PythonDeclReference = PythonDeclReference;
type PythonAST_PythonDeclType = PythonDeclType;
type PythonAST_PythonDeclaration = PythonDeclaration;
type PythonAST_PythonFunctionParameter = PythonFunctionParameter;
type PythonAST_PythonGenericParameter = PythonGenericParameter;
type PythonAST_PythonIdentifier = PythonIdentifier;
type PythonAST_PythonLiteral = PythonLiteral;
type PythonAST_PythonType = PythonType;
type PythonAST_PythonTypeAny = PythonTypeAny;
type PythonAST_PythonTypeArray = PythonTypeArray;
type PythonAST_PythonTypeBool = PythonTypeBool;
type PythonAST_PythonTypeClass = PythonTypeClass;
type PythonAST_PythonTypeFloat = PythonTypeFloat;
type PythonAST_PythonTypeInt = PythonTypeInt;
type PythonAST_PythonTypeLiteral = PythonTypeLiteral;
type PythonAST_PythonTypeMap = PythonTypeMap;
type PythonAST_PythonTypeReference = PythonTypeReference;
type PythonAST_PythonTypeString = PythonTypeString;
type PythonAST_PythonTypeUnknown = PythonTypeUnknown;
declare namespace PythonAST {
  export type {
    PythonAST_PythonDeclClass as PythonDeclClass,
    PythonAST_PythonDeclFunction as PythonDeclFunction,
    PythonAST_PythonDeclProperty as PythonDeclProperty,
    PythonAST_PythonDeclReference as PythonDeclReference,
    PythonAST_PythonDeclType as PythonDeclType,
    PythonAST_PythonDeclaration as PythonDeclaration,
    PythonAST_PythonFunctionParameter as PythonFunctionParameter,
    PythonAST_PythonGenericParameter as PythonGenericParameter,
    PythonAST_PythonIdentifier as PythonIdentifier,
    PythonAST_PythonLiteral as PythonLiteral,
    PythonAST_PythonType as PythonType,
    PythonAST_PythonTypeAny as PythonTypeAny,
    PythonAST_PythonTypeArray as PythonTypeArray,
    PythonAST_PythonTypeBool as PythonTypeBool,
    PythonAST_PythonTypeClass as PythonTypeClass,
    PythonAST_PythonTypeFloat as PythonTypeFloat,
    PythonAST_PythonTypeInt as PythonTypeInt,
    PythonAST_PythonTypeLiteral as PythonTypeLiteral,
    PythonAST_PythonTypeMap as PythonTypeMap,
    PythonAST_PythonTypeReference as PythonTypeReference,
    PythonAST_PythonTypeString as PythonTypeString,
    PythonAST_PythonTypeUnknown as PythonTypeUnknown,
  };
}

type RubyDeclaration =
  | RubyDeclFunction
  | RubyDeclClass
  | RubyDeclProperty
  | RubyDeclTypeAlias
  | RubyDeclReference
  | ErrorDecl;
type RubyDeclFunction = BaseDeclaration & {
  kind: 'RubyDeclFunction';
  ident: RubyIdentifier;
  args: RubyFunctionArgument[];
  qualified?: string;
  returns?: RubyType;
  paramsChildren?: ID[];
  bodyParamsChildren?: Record<string, ID[]>;
  responseChildren?: ID[];
};
type RubyFunctionArgument = {
  kind: 'RubyFunctionArgument';
  ident: RubyIdentifier;
  optional: boolean;
  type: RubyType;
};
type RubyDeclProperty = BaseDeclaration & {
  kind: 'RubyDeclProperty';
  ident: string;
  docstring?: string;
  title?: string;
  location?: string;
  type: RubyType;
  constraints?: Constraints;
  optional?: boolean;
  examples?: unknown[];
  schemaType?: SchemaType;
  modelPath?: string;
  childrenParentSchema?: SchemaType;
  children?: ID[];
};
type RubyDeclClass = BaseDeclaration & {
  kind: 'RubyDeclClass';
  ident: string;
  docstring?: string;
  type: RubyType;
  optional?: boolean;
  children?: ID[];
};
type RubyDeclTypeAlias = BaseDeclaration & {
  kind: 'RubyDeclTypeAlias';
  docstring?: string;
  ident: RubyIdentifier;
  typeParameters?: RubyTypeParameter[];
  type: RubyType;
  children?: ID[];
};
type RubyTypeParameter = {
  kind: 'RubyTypeParameter';
  name: RubyIdentifier;
  constraint?: RubyType;
  default?: RubyType;
};
type RubyIdentifier = string;
type RubyDeclReference = BaseDeclaration & {
  kind: 'RubyDeclReference';
  docstring?: string;
  ident?: RubyIdentifier;
  type: RubyType;
  children?: ID[];
};
type RubyType =
  | RubyTypeReference
  | RubyTypeObject
  | RubyTypeArray
  | RubyTypeMap
  | RubyTypeString
  | RubyTypeInteger
  | RubyTypeFloat
  | RubyTypeBoolean
  | RubyTypeNull
  | RubyTypeBinary
  | RubyTypeUnknown
  | RubyTypeLiteral
  | RubyTypeUnion
  | RubyTypeIntersection
  | RubyTypeBuiltinClass;
type RubyTypeReference = BaseType & {
  kind: 'RubyTypeReference';
  ident: RubyIdentifier;
  typeParameters?: RubyType[];
  schemaType?: SchemaType;
  $ref?: ID;
};
type RubyTypeObject = BaseType & {
  kind: 'RubyTypeObject';
  ident: RubyIdentifier | null;
  members: {
    ident: RubyIdentifier;
    optional?: boolean;
  }[];
};
type RubyTypeMap = BaseType & {
  kind: 'RubyTypeMap';
  indexType: RubyType;
  itemType: RubyType;
};
type RubyTypeArray = BaseType & {
  kind: 'RubyTypeArray';
  elementType: RubyType;
};
type RubyTypeUnion = BaseType & {
  kind: 'RubyTypeUnion';
  types: RubyType[];
};
type RubyTypeIntersection = BaseType & {
  kind: 'RubyTypeIntersection';
  types: RubyType[];
};
type RubyTypeLiteral = BaseType & {
  kind: 'RubyTypeLiteral';
  literal: string | boolean | number;
};
type RubyTypeBuiltinClass = BaseType & {
  kind: 'RubyTypeBuiltinClass';
  className: string;
};
type RubyTypeString = BaseType & {
  kind: 'RubyTypeString';
};
type RubyTypeInteger = BaseType & {
  kind: 'RubyTypeInteger';
};
type RubyTypeFloat = BaseType & {
  kind: 'RubyTypeFloat';
};
type RubyTypeBoolean = BaseType & {
  kind: 'RubyTypeBoolean';
};
type RubyTypeNull = BaseType & {
  kind: 'RubyTypeNull';
};
type RubyTypeBinary = BaseType & {
  kind: 'RubyTypeBinary';
  contentType: string[];
};
type RubyTypeUnknown = BaseType & {
  kind: 'RubyTypeUnknown';
};

type RubyAST_RubyDeclClass = RubyDeclClass;
type RubyAST_RubyDeclFunction = RubyDeclFunction;
type RubyAST_RubyDeclProperty = RubyDeclProperty;
type RubyAST_RubyDeclReference = RubyDeclReference;
type RubyAST_RubyDeclTypeAlias = RubyDeclTypeAlias;
type RubyAST_RubyDeclaration = RubyDeclaration;
type RubyAST_RubyFunctionArgument = RubyFunctionArgument;
type RubyAST_RubyIdentifier = RubyIdentifier;
type RubyAST_RubyType = RubyType;
type RubyAST_RubyTypeArray = RubyTypeArray;
type RubyAST_RubyTypeBinary = RubyTypeBinary;
type RubyAST_RubyTypeBoolean = RubyTypeBoolean;
type RubyAST_RubyTypeBuiltinClass = RubyTypeBuiltinClass;
type RubyAST_RubyTypeFloat = RubyTypeFloat;
type RubyAST_RubyTypeInteger = RubyTypeInteger;
type RubyAST_RubyTypeIntersection = RubyTypeIntersection;
type RubyAST_RubyTypeLiteral = RubyTypeLiteral;
type RubyAST_RubyTypeMap = RubyTypeMap;
type RubyAST_RubyTypeNull = RubyTypeNull;
type RubyAST_RubyTypeObject = RubyTypeObject;
type RubyAST_RubyTypeParameter = RubyTypeParameter;
type RubyAST_RubyTypeReference = RubyTypeReference;
type RubyAST_RubyTypeString = RubyTypeString;
type RubyAST_RubyTypeUnion = RubyTypeUnion;
type RubyAST_RubyTypeUnknown = RubyTypeUnknown;
declare namespace RubyAST {
  export type {
    RubyAST_RubyDeclClass as RubyDeclClass,
    RubyAST_RubyDeclFunction as RubyDeclFunction,
    RubyAST_RubyDeclProperty as RubyDeclProperty,
    RubyAST_RubyDeclReference as RubyDeclReference,
    RubyAST_RubyDeclTypeAlias as RubyDeclTypeAlias,
    RubyAST_RubyDeclaration as RubyDeclaration,
    RubyAST_RubyFunctionArgument as RubyFunctionArgument,
    RubyAST_RubyIdentifier as RubyIdentifier,
    RubyAST_RubyType as RubyType,
    RubyAST_RubyTypeArray as RubyTypeArray,
    RubyAST_RubyTypeBinary as RubyTypeBinary,
    RubyAST_RubyTypeBoolean as RubyTypeBoolean,
    RubyAST_RubyTypeBuiltinClass as RubyTypeBuiltinClass,
    RubyAST_RubyTypeFloat as RubyTypeFloat,
    RubyAST_RubyTypeInteger as RubyTypeInteger,
    RubyAST_RubyTypeIntersection as RubyTypeIntersection,
    RubyAST_RubyTypeLiteral as RubyTypeLiteral,
    RubyAST_RubyTypeMap as RubyTypeMap,
    RubyAST_RubyTypeNull as RubyTypeNull,
    RubyAST_RubyTypeObject as RubyTypeObject,
    RubyAST_RubyTypeParameter as RubyTypeParameter,
    RubyAST_RubyTypeReference as RubyTypeReference,
    RubyAST_RubyTypeString as RubyTypeString,
    RubyAST_RubyTypeUnion as RubyTypeUnion,
    RubyAST_RubyTypeUnknown as RubyTypeUnknown,
  };
}

type StainlessMethodExample = {
  title?: string;
  request: Partial<
    Record<
      SupportedLanguage,
      {
        content: string;
      }
    >
  >;
  response: {
    content: string;
  };
};

type PrimitiveNumberProps$1 = {
  oneof?: (number | bigint)[];
  default: number | bigint | null;
  minimum: number | bigint | null;
  maximum: number | bigint | null;
};
type Primitive$1 = {
  category: 'primitive';
  schemaRef?: SDKSchemaReference;
} & (
  | {
      type: 'Bool';
      default: boolean | null;
    }
  | ({
      type: 'Float64';
    } & PrimitiveNumberProps$1)
  | ({
      type: 'Int64';
    } & PrimitiveNumberProps$1)
  | ({
      type: 'Number';
    } & PrimitiveNumberProps$1)
  | {
      type: 'Time';
      default: string | null;
    }
  | {
      type: 'String';
      oneof?: string[];
      default: string | null;
    }
);
type Dynamic$1 = {
  category: 'dynamic';
  type: 'Dynamic';
  schemaRef?: SDKSchemaReference;
  allowedSubtypes: Primitive$1['type'][];
};
type Unknown$1 = {
  category: 'unknown';
  type: 'unknown';
  schemaRef?: SDKSchemaReference;
};
type Collection$1 = {
  category: 'collection';
  type: 'List' | 'Map' | 'Set';
  elementType: AttributeType$1;
  schemaRef?: SDKSchemaReference;
};
type Nested$1 = {
  category: 'nested';
  type: 'ListNested' | 'MapNested' | 'SetNested' | 'SingleNested';
  attributes: TerraformAttribute[];
  schemaRef?: SDKSchemaReference;
  modelTypeName: string;
  validators: TerraformValidators;
};
type AttributeType$1 = Nested$1 | Collection$1 | Dynamic$1 | Primitive$1 | Unknown$1;
/**
 * required: The value must be practitioner configured to an eventually known value (not null),
 *   otherwise the framework will automatically raise an error diagnostic for the missing value.
 *
 * optional: The value may be practitioner configured to a known value or null.
 *
 * computed: The value will be set in provider logic and any practitioner configuration causes
 *   the framework to automatically raise an error diagnostic for the unexpected configuration value.
 *
 * computed_optional: The value may be practitioner configured or the value may be set in
 *   provider logic when the practitioner configuration is null.
 */
type Configurability = 'required' | 'optional' | 'computed' | 'computed_optional';
type TerraformSchemaType = 'resource' | 'provider' | 'datasource';
type PathExpr$1 = Readonly<{
  path: string;
  container?: Collection$1['type'] | Nested$1['type'];
}>;
type PathExpression$1 = readonly PathExpr$1[];
type TerraformAttribute = {
  name: string;
  description?: string;
  configurability: Configurability;
  configurabilityOverride: boolean;
  property?: SDKPropertySchemaReference;
  type: AttributeType$1;
  idProperty?: boolean;
  requiresReplace?: boolean;
  sensitive?: boolean;
  deprecated?: string | boolean;
  noRefresh?: boolean;
  isBodyRootParam?: boolean;
  syntheticType?: 'id' | 'find-by' | 'max-items' | 'items' | 'timeout';
  schemaType: TerraformSchemaType;
  pathExpr: PathExpression$1;
  /** whether this attribute is immediately nested inside a computed (or computed_optional) collection/object */
  nestedInComputedAttribute?: boolean;
};
declare const TerraformPathValidations: readonly [
  'requiredTogether',
  'atLeastOneOf',
  'exactlyOneOf',
  'conflicting',
];
type PathValidators = Record<(typeof TerraformPathValidations)[number], PathExpression$1[][]>;
type TerraformValidators = {
  path: PathValidators;
  any: never[];
  all: never[];
};

type TerraformNode = TerraformDeclaration;
type TerraformDeclaration =
  | TerraformDeclServiceNode
  | TerraformDeclSource
  | TerraformDeclAttribute
  | ErrorDecl;
type TerraformDeclServiceNode = BaseDeclaration & {
  kind: 'TerraformDeclServiceNode';
  resource?: ID;
  dataSource?: ID;
  listDataSource?: ID;
};
type TerraformDeclSource = BaseDeclaration & {
  kind: 'TerraformDeclSource';
  name: string;
  type: 'resource' | 'datasource-plural' | 'datasource-single';
  methodName: string;
  required: ID[];
  optional: ID[];
  computed: ID[];
};
type PrimitiveNumberProps = {
  oneof?: number[];
  default: number | null;
  minimum: number | null;
  maximum: number | null;
};
type Primitive = {
  category: 'primitive';
} & (
  | {
      type: 'Bool';
      default: boolean | null;
    }
  | ({
      type: 'Float64';
    } & PrimitiveNumberProps)
  | ({
      type: 'Int64';
    } & PrimitiveNumberProps)
  | ({
      type: 'Number';
    } & PrimitiveNumberProps)
  | {
      type: 'Time';
      default: string | null;
    }
  | {
      type: 'String';
      oneof?: string[];
      default: string | null;
    }
);
type Dynamic = {
  category: 'dynamic';
  type: 'Dynamic';
  allowedSubtypes: Primitive['type'][];
};
type Unknown = {
  category: 'unknown';
  type: 'unknown';
};
type Collection = {
  category: 'collection';
  type: 'List' | 'Map' | 'Set';
  elementType: AttributeType;
};
type Nested = {
  category: 'nested';
  type: 'ListNested' | 'MapNested' | 'SetNested' | 'SingleNested';
  modelTypeName: string;
  validators: TerraformValidators;
};
type MethodNames = 'create' | 'read' | 'list' | 'update' | 'delete';
type Timeouts = {
  propertyName: string;
  block: boolean;
  type: 'resource' | 'datasource';
  timeouts: {
    [key in MethodNames]: number | undefined;
  };
};
type AttributeType = Nested | Collection | Dynamic | Primitive | Unknown;
type PathExpr = Readonly<{
  path: string;
  container?: Collection['type'] | Nested['type'];
}>;
type PathExpression = readonly PathExpr[];
type TerraformDeclAttribute = BaseDeclaration & {
  kind: 'TerraformDeclAttribute';
  name: string;
  docstring?: string;
  type: AttributeType;
  children: ID[];
  configurability: Configurability;
  requiresReplace?: boolean;
};

type TerraformAST_AttributeType = AttributeType;
type TerraformAST_Collection = Collection;
type TerraformAST_Dynamic = Dynamic;
type TerraformAST_Nested = Nested;
type TerraformAST_PathExpr = PathExpr;
type TerraformAST_PathExpression = PathExpression;
type TerraformAST_Primitive = Primitive;
type TerraformAST_PrimitiveNumberProps = PrimitiveNumberProps;
type TerraformAST_TerraformDeclAttribute = TerraformDeclAttribute;
type TerraformAST_TerraformDeclServiceNode = TerraformDeclServiceNode;
type TerraformAST_TerraformDeclSource = TerraformDeclSource;
type TerraformAST_TerraformDeclaration = TerraformDeclaration;
type TerraformAST_TerraformNode = TerraformNode;
type TerraformAST_Timeouts = Timeouts;
type TerraformAST_Unknown = Unknown;
declare namespace TerraformAST {
  export type {
    TerraformAST_AttributeType as AttributeType,
    TerraformAST_Collection as Collection,
    TerraformAST_Dynamic as Dynamic,
    TerraformAST_Nested as Nested,
    TerraformAST_PathExpr as PathExpr,
    TerraformAST_PathExpression as PathExpression,
    TerraformAST_Primitive as Primitive,
    TerraformAST_PrimitiveNumberProps as PrimitiveNumberProps,
    TerraformAST_TerraformDeclAttribute as TerraformDeclAttribute,
    TerraformAST_TerraformDeclServiceNode as TerraformDeclServiceNode,
    TerraformAST_TerraformDeclSource as TerraformDeclSource,
    TerraformAST_TerraformDeclaration as TerraformDeclaration,
    TerraformAST_TerraformNode as TerraformNode,
    TerraformAST_Timeouts as Timeouts,
    TerraformAST_Unknown as Unknown,
  };
}

type TSDeclaration =
  | TSDeclFunction
  | TSDeclClass
  | TSDeclInterface
  | TSDeclProperty
  | TSDeclTypeAlias
  | TSDeclReference
  | ErrorDecl;
type TSDeclFunction = BaseDeclaration & {
  kind: 'TSDeclFunction';
  ident: TSIdentifier;
  qualified?: string;
  signature: TSFunctionSignature;
  overloads?: TSFunctionSignature[];
  paramsChildren?: ID[];
  responseChildren?: ID[];
};
type TSDeclClass = BaseDeclaration & {
  kind: 'TSDeclClass';
  ident: TSIdentifier;
  docstring?: string;
  typeParameters?: TSTypeParameter[];
  superClass?: TSTypeReference;
  implements?: TSTypeReference[];
  children: ID[];
};
type TSDeclInterface = BaseDeclaration & {
  kind: 'TSDeclInterface';
  ident: TSIdentifier;
  docstring?: string;
  typeParameters?: TSTypeParameter[];
  extends?: TSType[];
  children: ID[];
};
type TSDeclProperty = BaseDeclaration & {
  kind: 'TSDeclProperty';
  key: string;
  docstring?: string;
  title?: string;
  type: TSType;
  constraints?: Constraints;
  optional?: boolean;
  declare?: boolean;
  default?: unknown;
  examples?: unknown[];
  schemaType?: SchemaType;
  modelPath?: string;
  childrenParentSchema?: SchemaType;
  children?: ID[];
};
type TSDeclTypeAlias = BaseDeclaration & {
  kind: 'TSDeclTypeAlias';
  docstring?: string;
  ident: TSIdentifier;
  typeParameters?: TSTypeParameter[];
  type: TSType;
  children?: ID[];
};
type TSDeclReference = BaseDeclaration & {
  kind: 'TSDeclReference';
  docstring?: string;
  type: TSType;
  children?: ID[];
};
type TSFunctionSignature = {
  kind: 'TSFunctionSignature';
  parameters: TSFunctionParameter[];
  returns: TSType;
  async?: boolean;
  typeParameters?: TSTypeParameter[];
  docstring?: string;
};
type TSFunctionParameter = {
  kind: 'TSFunctionParameter';
  ident: TSIdentifier;
  type: TSType;
  optional?: boolean;
};
type TSTypeParameter = {
  kind: 'TSTypeParameter';
  name: TSIdentifier;
  constraint?: TSType;
  default?: TSType;
};
type TSPropertyKey = TSIdentifier;
type TSIdentifier = string;
type TSType =
  | TSTypeReference
  | TSTypeObject
  | TSTypeArray
  | TSTypeString
  | TSTypeNumber
  | TSTypeBoolean
  | TSTypeNull
  | TSTypeUndefined
  | TSTypeVoid
  | TSTypeAny
  | TSTypeUnknown
  | TSTypeNever
  | TSTypeLiteral
  | TSTypeUnion
  | TSTypeIntersection
  | TSTypeInterface;
type TSTypeReference = BaseType & {
  kind: 'TSTypeReference';
  ident: TSIdentifier;
  typeParameters?: TSType[];
  schemaType?: SchemaType;
  $ref?: ID;
};
type TSTypeObject = BaseType & {
  kind: 'TSTypeObject';
  members: {
    ident: TSIdentifier;
    type: TSType;
    optional?: boolean;
  }[];
};
type TSTypeArray = BaseType & {
  kind: 'TSTypeArray';
  elementType: TSType;
};
type TSTypeUnion = BaseType & {
  kind: 'TSTypeUnion';
  types: TSType[];
};
type TSTypeIntersection = BaseType & {
  kind: 'TSTypeIntersection';
  types: TSType[];
};
type TSTypeInterface = BaseType & {
  kind: 'TSTypeInterface';
  members: {
    ident: TSIdentifier;
    type: TSType;
    optional?: boolean;
  }[];
  extends?: TSTypeReference[];
};
type TSTypeLiteral = BaseType & {
  kind: 'TSTypeLiteral';
  literal: string | boolean | number;
};
type TSTypeString = BaseType & {
  kind: 'TSTypeString';
};
type TSTypeNumber = BaseType & {
  kind: 'TSTypeNumber';
};
type TSTypeBoolean = BaseType & {
  kind: 'TSTypeBoolean';
};
type TSTypeNull = BaseType & {
  kind: 'TSTypeNull';
};
type TSTypeUndefined = BaseType & {
  kind: 'TSTypeUndefined';
};
type TSTypeVoid = BaseType & {
  kind: 'TSTypeVoid';
};
type TSTypeAny = BaseType & {
  kind: 'TSTypeAny';
};
type TSTypeUnknown = BaseType & {
  kind: 'TSTypeUnknown';
};
type TSTypeNever = BaseType & {
  kind: 'TSTypeNever';
};

type TSAST_TSDeclClass = TSDeclClass;
type TSAST_TSDeclFunction = TSDeclFunction;
type TSAST_TSDeclInterface = TSDeclInterface;
type TSAST_TSDeclProperty = TSDeclProperty;
type TSAST_TSDeclReference = TSDeclReference;
type TSAST_TSDeclTypeAlias = TSDeclTypeAlias;
type TSAST_TSDeclaration = TSDeclaration;
type TSAST_TSFunctionParameter = TSFunctionParameter;
type TSAST_TSFunctionSignature = TSFunctionSignature;
type TSAST_TSIdentifier = TSIdentifier;
type TSAST_TSPropertyKey = TSPropertyKey;
type TSAST_TSType = TSType;
type TSAST_TSTypeAny = TSTypeAny;
type TSAST_TSTypeArray = TSTypeArray;
type TSAST_TSTypeBoolean = TSTypeBoolean;
type TSAST_TSTypeInterface = TSTypeInterface;
type TSAST_TSTypeIntersection = TSTypeIntersection;
type TSAST_TSTypeLiteral = TSTypeLiteral;
type TSAST_TSTypeNever = TSTypeNever;
type TSAST_TSTypeNull = TSTypeNull;
type TSAST_TSTypeNumber = TSTypeNumber;
type TSAST_TSTypeObject = TSTypeObject;
type TSAST_TSTypeParameter = TSTypeParameter;
type TSAST_TSTypeReference = TSTypeReference;
type TSAST_TSTypeString = TSTypeString;
type TSAST_TSTypeUndefined = TSTypeUndefined;
type TSAST_TSTypeUnion = TSTypeUnion;
type TSAST_TSTypeUnknown = TSTypeUnknown;
type TSAST_TSTypeVoid = TSTypeVoid;
declare namespace TSAST {
  export type {
    TSAST_TSDeclClass as TSDeclClass,
    TSAST_TSDeclFunction as TSDeclFunction,
    TSAST_TSDeclInterface as TSDeclInterface,
    TSAST_TSDeclProperty as TSDeclProperty,
    TSAST_TSDeclReference as TSDeclReference,
    TSAST_TSDeclTypeAlias as TSDeclTypeAlias,
    TSAST_TSDeclaration as TSDeclaration,
    TSAST_TSFunctionParameter as TSFunctionParameter,
    TSAST_TSFunctionSignature as TSFunctionSignature,
    TSAST_TSIdentifier as TSIdentifier,
    TSAST_TSPropertyKey as TSPropertyKey,
    TSAST_TSType as TSType,
    TSAST_TSTypeAny as TSTypeAny,
    TSAST_TSTypeArray as TSTypeArray,
    TSAST_TSTypeBoolean as TSTypeBoolean,
    TSAST_TSTypeInterface as TSTypeInterface,
    TSAST_TSTypeIntersection as TSTypeIntersection,
    TSAST_TSTypeLiteral as TSTypeLiteral,
    TSAST_TSTypeNever as TSTypeNever,
    TSAST_TSTypeNull as TSTypeNull,
    TSAST_TSTypeNumber as TSTypeNumber,
    TSAST_TSTypeObject as TSTypeObject,
    TSAST_TSTypeParameter as TSTypeParameter,
    TSAST_TSTypeReference as TSTypeReference,
    TSAST_TSTypeString as TSTypeString,
    TSAST_TSTypeUndefined as TSTypeUndefined,
    TSAST_TSTypeUnion as TSTypeUnion,
    TSAST_TSTypeUnknown as TSTypeUnknown,
    TSAST_TSTypeVoid as TSTypeVoid,
  };
}

type HasOASRef = {
  oasRef?: string;
};
type HasConfigRef = {
  configRef: string;
};
type HasStainlessPath = {
  stainlessPath: string;
};
type ID = string & {
  _isId: null;
};
type SchemaType = SDKSchemaType;
declare const constraints: readonly [
  'minLength',
  'maxLength',
  'format',
  'minimum',
  'exclusiveMinimum',
  'maximum',
  'exclusiveMaximum',
  'multipleOf',
];
type Constraints = Pick<SchemaObject, (typeof constraints)[number]>;
declare function constraintsFromSchema(rawSchema: SchemaObject):
  | {
      [k: string]: any;
    }
  | undefined;
declare const SpecLanguages: readonly [
  'cli',
  'csharp',
  'go',
  'http',
  'java',
  'kotlin',
  'node',
  'php',
  'python',
  'ruby',
  'terraform',
  'typescript',
];
type SpecLanguage = (typeof SpecLanguages)[number];
declare function isSpecLanguage(language: string): language is SpecLanguage;
declare const SnippetLanguages: readonly [
  'cli.default',
  'csharp.default',
  'go.default',
  'http.curl',
  'http.powershell',
  'java.default',
  'kotlin.default',
  'node.default',
  'php.default',
  'python.default',
  'ruby.default',
  'terraform.default',
  'typescript.default',
];
type SnippetLanguage<lang extends SpecLanguage = SpecLanguage> = (typeof SnippetLanguages)[number] &
  `${lang}.${string}`;
/**
 * A literal property path from Spec down to a given node
 */
type Path = (string | number)[];
/**
 * A literal property path from Spec down to a given node
 */
type PathLike = string | (string | number)[];
type Node = Spec | Resource | Method | Model;
/**
 * Checks if thing is an Node.
 * Not a sound check, it should only be called on values within an
 * tree, and it only works because no node has a property
 * of type Record<string, string>.
 */
declare function isNode(thing: unknown): thing is Node;
type DeclRefType =
  | HttpDeclReference
  | TSDeclReference
  | PythonDeclReference
  | GoDeclReference
  | GoDeclConst
  | RubyDeclReference
  | JavaDeclReference
  | PhpDeclReference;
type Type =
  | HttpType
  | TSType
  | PythonType
  | GoType
  | RubyType
  | JavaType
  | CSharpType
  | AttributeType
  | PhpType;
type PropertyType =
  | HttpDeclProperty
  | TSDeclProperty
  | PythonDeclProperty
  | GoDeclProperty
  | RubyDeclProperty
  | JavaDeclProperty
  | PhpDeclClassProperty;
type Spec = {
  name: string;
  kind: 'spec';
  security_schemes: {
    type: 'http_bearer' | 'query' | 'header' | 'oauth2' | 'http_basic' | 'http_digest';
    description?: string;
    name: string;
    title: string;
    header: string | undefined;
    example: string | undefined;
  }[];
  resources: Record<string, Resource>;
  diagnostics: Diagnostics;
  docs?: Config['docs'];
  metadata: {
    [lang in SpecLanguage]?: {
      repo_url?: string;
      code_url?: string;
      package_title?: string;
      version?: string;
      install?: string;
    };
  };
  readme: {
    [lang in SpecLanguage]?: string;
  };
  decls: {
    [lang in SpecLanguage]?: Record<string, LanguageDeclNodes[lang]>;
  };
  snippets: {
    [key in SnippetLanguage]?: Record<
      string,
      {
        default: {
          content: string;
        };
        [key: `custom:${string}`]: {
          content: string;
        };
      }
    >;
  };
  snippetResponses: {
    http: Record<
      string,
      {
        default?: {
          status: string;
          content: string;
          contentType?: string;
        }[];
        [key: `custom:${string}`]: {
          status?: string;
          content: string;
        }[];
      }
    >;
  };
};
type Resource = (HasConfigRef & HasStainlessPath) & {
  kind: 'resource';
  name: string;
  title: string;
  configRef: string;
  description?: string;
  models: Record<string, Model>;
  methods: Record<string, Method>;
  subresources?: Record<string, Resource>;
} & {
  [key in SpecLanguage]?: {
    Name: string;
    QualifiedName: string;
  };
};
type Method = (HasStainlessPath & HasOASRef) & {
  kind: 'http_method';
  name: string;
  title: string;
  configRef: string | undefined;
  description?: string;
  summary?: string;
  httpMethod: string;
  endpoint: string;
  deprecated?: string | boolean;
  /** @deprecated - use snippetResponses at the top level */
  exampleResponses?: Record<string, ResponseContentObject>;
  security: Record<string, string[]>[] | undefined;
  'x-api-token-group'?: string[];
} & {
  [key in SpecLanguage]?: {
    Name: string;
    QualifiedName: string;
  };
};
type StainlessMethodInfo =
  | StainlessHttpMethodInfo
  | StainlessAliasMethodInfo
  | StainlessWebhookUnwrapMethodInfo;
type StainlessHttpMethodInfo = {
  kind: 'http_method_info';
  httpMethod: HTTPMethod;
  path: string;
};
type StainlessAliasMethodInfo = {
  kind: 'alias_method_info';
  httpMethod: HTTPMethod;
  path: string;
};
type StainlessWebhookUnwrapMethodInfo = {
  kind: 'webhook_unwrap_method_info';
};

type Parameter = (HasOASRef & HasStainlessPath) & {
  kind: 'parameter';
  key: string;
  name: string;
  location: string;
  description?: string;
  isRequired?: boolean;
  isPositional: boolean;
};
type Model = (HasOASRef & HasConfigRef & HasStainlessPath) & {
  kind: 'model';
  name: string;
  title: string;
  isImplicit: boolean;
  stainlessPath: string;
  configRef: string;
  loading?: boolean;
};
type BaseDeclaration = {
  stainlessPath: string;
  oasRef?: string;
  configRef?: string;
  loading?: boolean;
  deprecated?: boolean | string;
  snippet?: string;
};
type BaseType = {
  oasRef?: string;
};
type Diagnostics = Record<string, DiagnosticExport[]>;
type Diagnostic = DiagnosticExport;
type LanguageDeclNodes = {
  cli: CLIDeclaration;
  csharp: CSharpDeclaration;
  go: GoDeclaration;
  http: HttpDeclaration;
  java: JavaDeclaration;
  kotlin: JavaDeclaration;
  node: TSDeclaration;
  php: PhpDeclaration;
  python: PythonDeclaration;
  ruby: RubyDeclaration;
  terraform: TerraformDeclaration;
  typescript: TSDeclaration;
};
type ErrorDecl = BaseDeclaration & {
  kind: 'ErrorDecl';
  error: Error;
  message: string;
};
type DeclarationNode = LanguageDeclNodes[SpecLanguage];
declare function declare<T extends BaseDeclaration>(
  map: Map<string, T>,
  stainlessPath: string,
  generator: () => Omit<T, 'stainlessPath'>,
): ID;
declare function declareAll<T extends BaseDeclaration>(
  map: Map<string, T>,
  items: Array<{
    stainlessPath: string;
    generator: () => Omit<T, 'stainlessPath'>;
  }>,
): ID[];
declare function schemaChildrenParent(schema: SDKSchema): SDKSchemaType | undefined;
declare function processReadme(
  content: string,
  language: SupportedLanguage,
  languageSnippets: Record<string, unknown>,
): string;

type GoDeclaration =
  | GoDeclFunction
  | GoDeclType
  | GoDeclProperty
  | GoDeclTypeAlias
  | GoDeclConst
  | GoDeclReference
  | ErrorDecl;
type GoDeclFunction = BaseDeclaration & {
  kind: 'GoDeclFunction';
  ident: GoIdentifier;
  qualified?: string;
  docstring?: string;
  async?: boolean;
  generics?: GoGenericParameter[];
  parameters: GoFunctionParameter[];
  returnType: GoType[];
  paramsChildren?: ID[];
  responseChildren?: ID[];
};
type GoFunctionParameter = {
  kind: 'GoFunctionParameter';
  optional?: boolean;
  ident: GoIdentifier;
  typeAnnotation: GoType;
};
type GoGenericParameter = {
  kind: 'GoTypeParameter';
  name: string;
  constraint?: GoType;
};
type GoDeclType = BaseDeclaration & {
  kind: 'GoDeclType';
  docstring?: string;
  ident: GoIdentifier;
  generics?: GoGenericParameter[];
  type: GoType;
  children?: ID[];
};
type GoDeclTypeAlias = BaseDeclaration & {
  kind: 'GoDeclTypeAlias';
  docstring?: string;
  ident: GoIdentifier;
  type: GoType;
  children?: ID[];
};
type GoDeclConst = BaseDeclaration & {
  kind: 'GoDeclConst';
  docstring?: string;
  ident: GoIdentifier;
  type: GoType;
  value: boolean | string | number;
  children?: ID[];
};
type GoIdentifier = string;
type GoDeclProperty = BaseDeclaration & {
  kind: 'GoDeclProperty';
  docstring?: string;
  title?: string;
  ident: GoIdentifier;
  type: GoType;
  constraints?: Constraints;
  optional?: boolean;
  default?: unknown;
  examples?: unknown[];
  schemaType?: SchemaType;
  modelPath?: string;
  childrenParentSchema?: SchemaType;
  children?: ID[];
};
type GoDeclReference = BaseDeclaration & {
  kind: 'GoDeclReference';
  docstring?: string;
  type: GoType;
  children?: ID[];
};
type GoType =
  | GoTypeReference
  | GoTypeInterface
  | GoTypeStruct
  | GoTypeArray
  | GoTypeMap
  | GoTypeString
  | GoTypeFloat
  | GoTypeInt
  | GoTypeBool
  | GoTypeAny
  | GoTypeUnknown
  | GoTypeError
  | GoTypePointer;
type GoTypeReference = BaseType & {
  kind: 'GoTypeReference';
  typeName: GoIdentifier;
  typeParameters?: GoType[];
  schemaType?: SchemaType;
  $ref?: string;
};
type GoTypeStruct = BaseType & {
  kind: 'GoTypeStruct';
};
type GoTypeInterface = BaseType & {
  kind: 'GoTypeInterface';
  docstring?: string;
  typeName?: GoIdentifier;
  generics?: GoGenericParameter[];
  extends?: GoTypeReference[];
};
type GoTypeArray = BaseType & {
  kind: 'GoTypeArray';
  elementType: GoType;
};
type GoTypeMap = BaseType & {
  kind: 'GoTypeMap';
  indexType: GoType;
  itemType: GoType;
};
type GoTypeString = BaseType & {
  kind: 'GoTypeString';
};
type GoTypeFloat = BaseType & {
  kind: 'GoTypeFloat';
};
type GoTypeInt = BaseType & {
  kind: 'GoTypeInt';
};
type GoTypeBool = BaseType & {
  kind: 'GoTypeBool';
};
type GoTypeAny = BaseType & {
  kind: 'GoTypeAny';
};
type GoTypeUnknown = BaseType & {
  kind: 'GoTypeUnknown';
};
type GoTypeError = BaseType & {
  kind: 'GoTypeError';
};
type GoTypePointer = BaseType & {
  kind: 'GoTypePointer';
  inner: GoType;
};

type GoAST_GoDeclConst = GoDeclConst;
type GoAST_GoDeclFunction = GoDeclFunction;
type GoAST_GoDeclProperty = GoDeclProperty;
type GoAST_GoDeclReference = GoDeclReference;
type GoAST_GoDeclType = GoDeclType;
type GoAST_GoDeclTypeAlias = GoDeclTypeAlias;
type GoAST_GoDeclaration = GoDeclaration;
type GoAST_GoFunctionParameter = GoFunctionParameter;
type GoAST_GoGenericParameter = GoGenericParameter;
type GoAST_GoIdentifier = GoIdentifier;
type GoAST_GoType = GoType;
type GoAST_GoTypeAny = GoTypeAny;
type GoAST_GoTypeArray = GoTypeArray;
type GoAST_GoTypeBool = GoTypeBool;
type GoAST_GoTypeError = GoTypeError;
type GoAST_GoTypeFloat = GoTypeFloat;
type GoAST_GoTypeInt = GoTypeInt;
type GoAST_GoTypeInterface = GoTypeInterface;
type GoAST_GoTypeMap = GoTypeMap;
type GoAST_GoTypePointer = GoTypePointer;
type GoAST_GoTypeReference = GoTypeReference;
type GoAST_GoTypeString = GoTypeString;
type GoAST_GoTypeStruct = GoTypeStruct;
type GoAST_GoTypeUnknown = GoTypeUnknown;
declare namespace GoAST {
  export type {
    GoAST_GoDeclConst as GoDeclConst,
    GoAST_GoDeclFunction as GoDeclFunction,
    GoAST_GoDeclProperty as GoDeclProperty,
    GoAST_GoDeclReference as GoDeclReference,
    GoAST_GoDeclType as GoDeclType,
    GoAST_GoDeclTypeAlias as GoDeclTypeAlias,
    GoAST_GoDeclaration as GoDeclaration,
    GoAST_GoFunctionParameter as GoFunctionParameter,
    GoAST_GoGenericParameter as GoGenericParameter,
    GoAST_GoIdentifier as GoIdentifier,
    GoAST_GoType as GoType,
    GoAST_GoTypeAny as GoTypeAny,
    GoAST_GoTypeArray as GoTypeArray,
    GoAST_GoTypeBool as GoTypeBool,
    GoAST_GoTypeError as GoTypeError,
    GoAST_GoTypeFloat as GoTypeFloat,
    GoAST_GoTypeInt as GoTypeInt,
    GoAST_GoTypeInterface as GoTypeInterface,
    GoAST_GoTypeMap as GoTypeMap,
    GoAST_GoTypePointer as GoTypePointer,
    GoAST_GoTypeReference as GoTypeReference,
    GoAST_GoTypeString as GoTypeString,
    GoAST_GoTypeStruct as GoTypeStruct,
    GoAST_GoTypeUnknown as GoTypeUnknown,
  };
}

export {
  CLIAST,
  CSharpAST,
  GoAST,
  HttpAST,
  JavaAST,
  PhpAST,
  PythonAST,
  RubyAST,
  SnippetLanguages,
  SpecLanguages,
  TSAST,
  TerraformAST,
  constraints,
  constraintsFromSchema,
  declare,
  declareAll,
  isNode,
  isSpecLanguage,
  processReadme,
  schemaChildrenParent,
};
export type {
  BaseDeclaration,
  BaseType,
  Constraints,
  DeclRefType,
  DeclarationNode,
  Diagnostic,
  Diagnostics,
  ErrorDecl,
  HasConfigRef,
  HasOASRef,
  HasStainlessPath,
  ID,
  LanguageDeclNodes,
  Method,
  Model,
  Node,
  Parameter,
  Path,
  PathLike,
  PropertyType,
  Resource,
  SchemaType,
  SnippetLanguage,
  Spec,
  SpecLanguage,
  StainlessAliasMethodInfo,
  StainlessHttpMethodInfo,
  StainlessMethodExample,
  StainlessMethodInfo,
  StainlessWebhookUnwrapMethodInfo,
  Type,
};
