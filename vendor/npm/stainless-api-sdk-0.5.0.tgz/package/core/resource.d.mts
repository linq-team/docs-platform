import type { Stainless } from "../client.mjs";
export declare abstract class APIResource {
    protected _client: Stainless;
    constructor(client: Stainless);
}
//# sourceMappingURL=resource.d.mts.map