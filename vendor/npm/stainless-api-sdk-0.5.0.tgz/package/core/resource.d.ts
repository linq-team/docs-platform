import type { Stainless } from "../client.js";
export declare abstract class APIResource {
    protected _client: Stainless;
    constructor(client: Stainless);
}
//# sourceMappingURL=resource.d.ts.map