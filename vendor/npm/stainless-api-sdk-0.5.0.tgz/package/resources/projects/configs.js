"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Configs = void 0;
const resource_1 = require("../../core/resource.js");
const path_1 = require("../../internal/utils/path.js");
class Configs extends resource_1.APIResource {
    /**
     * Retrieve the configuration files for a given project.
     */
    retrieve(params = {}, options) {
        const { project = this._client.project, ...query } = params ?? {};
        return this._client.get((0, path_1.path) `/v0/projects/${project}/configs`, { query, ...options });
    }
    /**
     * Generate suggestions for changes to config files based on an OpenAPI spec.
     */
    guess(params, options) {
        const { project = this._client.project, ...body } = params;
        return this._client.post((0, path_1.path) `/v0/projects/${project}/configs/guess`, { body, ...options });
    }
}
exports.Configs = Configs;
//# sourceMappingURL=configs.js.map