// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as BranchesAPI from "./branches.mjs";
import { Branches, } from "./branches.mjs";
import * as ConfigsAPI from "./configs.mjs";
import { Configs, } from "./configs.mjs";
import { Page } from "../../core/pagination.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Projects extends APIResource {
    constructor() {
        super(...arguments);
        this.branches = new BranchesAPI.Branches(this._client);
        this.configs = new ConfigsAPI.Configs(this._client);
    }
    /**
     * Create a new project.
     */
    create(body, options) {
        return this._client.post('/v0/projects', { body, ...options });
    }
    /**
     * Retrieve a project by name.
     */
    retrieve(params = {}, options) {
        const { project = this._client.project } = params ?? {};
        return this._client.get(path `/v0/projects/${project}`, options);
    }
    /**
     * Update a project's properties.
     */
    update(params = {}, options) {
        const { project = this._client.project, ...body } = params ?? {};
        return this._client.patch(path `/v0/projects/${project}`, { body, ...options });
    }
    /**
     * List projects in an organization, from oldest to newest.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/v0/projects', (Page), { query, ...options });
    }
    /**
     * Generates an AI commit message by comparing two git refs in the SDK repository.
     */
    generateCommitMessage(params, options) {
        const { project = this._client.project, target, ...body } = params;
        return this._client.post(path `/v0/projects/${project}/generate_commit_message`, {
            query: { target },
            body,
            ...options,
        });
    }
}
Projects.Branches = Branches;
Projects.Configs = Configs;
//# sourceMappingURL=projects.mjs.map