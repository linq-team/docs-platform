// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { Page } from "../../core/pagination.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Branches extends APIResource {
    /**
     * Create a new branch for a project.
     *
     * The branch inherits the config files from the revision pointed to by the
     * `branch_from` parameter. In addition, if the revision is a branch name, the
     * branch will also inherit custom code changes from that branch.
     */
    create(params, options) {
        const { project = this._client.project, ...body } = params;
        return this._client.post(path `/v0/projects/${project}/branches`, { body, ...options });
    }
    /**
     * Retrieve a project branch by name.
     */
    retrieve(branch, params = {}, options) {
        const { project = this._client.project } = params ?? {};
        return this._client.get(path `/v0/projects/${project}/branches/${branch}`, options);
    }
    /**
     * Retrieve a project branch by name.
     */
    list(params = {}, options) {
        const { project = this._client.project, ...query } = params ?? {};
        return this._client.getAPIList(path `/v0/projects/${project}/branches`, (Page), {
            query,
            ...options,
        });
    }
    /**
     * Delete a project branch by name.
     */
    delete(branch, params = {}, options) {
        const { project = this._client.project } = params ?? {};
        return this._client.delete(path `/v0/projects/${project}/branches/${branch}`, options);
    }
    /**
     * Rebase a project branch.
     *
     * The branch is rebased onto the `base` branch or commit SHA, inheriting any
     * config and custom code changes.
     */
    rebase(branch, params = {}, options) {
        const { project = this._client.project, base } = params ?? {};
        return this._client.put(path `/v0/projects/${project}/branches/${branch}/rebase`, {
            query: { base },
            ...options,
        });
    }
    /**
     * Reset a project branch.
     *
     * If `branch` === `main`, the branch is reset to `target_config_sha`. Otherwise,
     * the branch is reset to `main`.
     */
    reset(branch, params = {}, options) {
        const { project = this._client.project, target_config_sha } = params ?? {};
        return this._client.put(path `/v0/projects/${project}/branches/${branch}/reset`, {
            query: { target_config_sha },
            ...options,
        });
    }
}
//# sourceMappingURL=branches.mjs.map