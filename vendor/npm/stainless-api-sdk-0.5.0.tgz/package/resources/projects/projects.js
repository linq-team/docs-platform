"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Projects = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const BranchesAPI = tslib_1.__importStar(require("./branches.js"));
const branches_1 = require("./branches.js");
const ConfigsAPI = tslib_1.__importStar(require("./configs.js"));
const configs_1 = require("./configs.js");
const pagination_1 = require("../../core/pagination.js");
const path_1 = require("../../internal/utils/path.js");
class Projects extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.branches = new BranchesAPI.Branches(this._client);
        this.configs = new ConfigsAPI.Configs(this._client);
    }
    /**
     * Create a new project.
     */
    create(body, options) {
        return this._client.post('/v0/projects', { body, ...options });
    }
    /**
     * Retrieve a project by name.
     */
    retrieve(params = {}, options) {
        const { project = this._client.project } = params ?? {};
        return this._client.get((0, path_1.path) `/v0/projects/${project}`, options);
    }
    /**
     * Update a project's properties.
     */
    update(params = {}, options) {
        const { project = this._client.project, ...body } = params ?? {};
        return this._client.patch((0, path_1.path) `/v0/projects/${project}`, { body, ...options });
    }
    /**
     * List projects in an organization, from oldest to newest.
     */
    list(query = {}, options) {
        return this._client.getAPIList('/v0/projects', (pagination_1.Page), { query, ...options });
    }
    /**
     * Generates an AI commit message by comparing two git refs in the SDK repository.
     */
    generateCommitMessage(params, options) {
        const { project = this._client.project, target, ...body } = params;
        return this._client.post((0, path_1.path) `/v0/projects/${project}/generate_commit_message`, {
            query: { target },
            body,
            ...options,
        });
    }
}
exports.Projects = Projects;
Projects.Branches = branches_1.Branches;
Projects.Configs = configs_1.Configs;
//# sourceMappingURL=projects.js.map