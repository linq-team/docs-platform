// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Configs extends APIResource {
    /**
     * Retrieve the configuration files for a given project.
     */
    retrieve(params = {}, options) {
        const { project = this._client.project, ...query } = params ?? {};
        return this._client.get(path `/v0/projects/${project}/configs`, { query, ...options });
    }
    /**
     * Generate suggestions for changes to config files based on an OpenAPI spec.
     */
    guess(params, options) {
        const { project = this._client.project, ...body } = params;
        return this._client.post(path `/v0/projects/${project}/configs/guess`, { body, ...options });
    }
}
//# sourceMappingURL=configs.mjs.map