import { APIResource } from "../../core/resource.js";
import * as Shared from "../shared.js";
import * as BranchesAPI from "./branches.js";
import { BranchCreateParams, BranchDeleteParams, BranchDeleteResponse, BranchListParams, BranchListResponse, BranchListResponsesPage, BranchRebaseParams, BranchResetParams, BranchRetrieveParams, Branches, ProjectBranch } from "./branches.js";
import * as ConfigsAPI from "./configs.js";
import { ConfigGuessParams, ConfigGuessResponse, ConfigRetrieveParams, ConfigRetrieveResponse, Configs } from "./configs.js";
import { APIPromise } from "../../core/api-promise.js";
import { Page, type PageParams, PagePromise } from "../../core/pagination.js";
import { RequestOptions } from "../../internal/request-options.js";
export declare class Projects extends APIResource {
    branches: BranchesAPI.Branches;
    configs: ConfigsAPI.Configs;
    /**
     * Create a new project.
     */
    create(body: ProjectCreateParams, options?: RequestOptions): APIPromise<Project>;
    /**
     * Retrieve a project by name.
     */
    retrieve(params?: ProjectRetrieveParams | null | undefined, options?: RequestOptions): APIPromise<Project>;
    /**
     * Update a project's properties.
     */
    update(params?: ProjectUpdateParams | null | undefined, options?: RequestOptions): APIPromise<Project>;
    /**
     * List projects in an organization, from oldest to newest.
     */
    list(query?: ProjectListParams | null | undefined, options?: RequestOptions): PagePromise<ProjectsPage, Project>;
    /**
     * Generates an AI commit message by comparing two git refs in the SDK repository.
     */
    generateCommitMessage(params: ProjectGenerateCommitMessageParams, options?: RequestOptions): APIPromise<ProjectGenerateCommitMessageResponse>;
}
export type ProjectsPage = Page<Project>;
/**
 * A project is a collection of SDKs generated from the same set of config files.
 */
export interface Project {
    config_repo: string;
    display_name: string | null;
    object: 'project';
    org: string;
    slug: string;
    targets: Array<Shared.Target>;
}
export interface ProjectGenerateCommitMessageResponse {
    ai_commit_message: string;
}
export interface ProjectCreateParams {
    /**
     * Human-readable project name
     */
    display_name: string;
    /**
     * Organization name
     */
    org: string;
    /**
     * File contents to commit
     */
    revision: {
        [key: string]: Shared.FileInput;
    };
    /**
     * Project name/slug
     */
    slug: string;
    /**
     * Targets to generate for
     */
    targets: Array<Shared.Target>;
}
export interface ProjectRetrieveParams {
    project?: string;
}
export interface ProjectUpdateParams {
    /**
     * Path param
     */
    project?: string;
    /**
     * Body param
     */
    display_name?: string | null;
}
export interface ProjectListParams extends PageParams {
    /**
     * Maximum number of projects to return, defaults to 10 (maximum: 100).
     */
    limit?: number;
    org?: string;
}
export interface ProjectGenerateCommitMessageParams {
    /**
     * Path param
     */
    project?: string;
    /**
     * Query param: Language target
     */
    target: 'python' | 'node' | 'typescript' | 'java' | 'kotlin' | 'go' | 'ruby' | 'terraform' | 'cli' | 'csharp' | 'php' | 'openapi' | 'sql';
    /**
     * Body param: Base ref for comparison
     */
    base_ref: string;
    /**
     * Body param: Head ref for comparison
     */
    head_ref: string;
}
export declare namespace Projects {
    export { type Project as Project, type ProjectGenerateCommitMessageResponse as ProjectGenerateCommitMessageResponse, type ProjectsPage as ProjectsPage, type ProjectCreateParams as ProjectCreateParams, type ProjectRetrieveParams as ProjectRetrieveParams, type ProjectUpdateParams as ProjectUpdateParams, type ProjectListParams as ProjectListParams, type ProjectGenerateCommitMessageParams as ProjectGenerateCommitMessageParams, };
    export { Branches as Branches, type ProjectBranch as ProjectBranch, type BranchListResponse as BranchListResponse, type BranchDeleteResponse as BranchDeleteResponse, type BranchListResponsesPage as BranchListResponsesPage, type BranchCreateParams as BranchCreateParams, type BranchRetrieveParams as BranchRetrieveParams, type BranchListParams as BranchListParams, type BranchDeleteParams as BranchDeleteParams, type BranchRebaseParams as BranchRebaseParams, type BranchResetParams as BranchResetParams, };
    export { Configs as Configs, type ConfigRetrieveResponse as ConfigRetrieveResponse, type ConfigGuessResponse as ConfigGuessResponse, type ConfigRetrieveParams as ConfigRetrieveParams, type ConfigGuessParams as ConfigGuessParams, };
}
//# sourceMappingURL=projects.d.ts.map