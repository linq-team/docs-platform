import { APIResource } from "../../core/resource.mjs";
import { APIPromise } from "../../core/api-promise.mjs";
import { RequestOptions } from "../../internal/request-options.mjs";
export declare class Configs extends APIResource {
    /**
     * Retrieve the configuration files for a given project.
     */
    retrieve(params?: ConfigRetrieveParams | null | undefined, options?: RequestOptions): APIPromise<ConfigRetrieveResponse>;
    /**
     * Generate suggestions for changes to config files based on an OpenAPI spec.
     */
    guess(params: ConfigGuessParams, options?: RequestOptions): APIPromise<ConfigGuessResponse>;
}
/**
 * Config files contents
 */
export type ConfigRetrieveResponse = {
    [key: string]: ConfigRetrieveResponse.item;
};
export declare namespace ConfigRetrieveResponse {
    interface item {
        /**
         * The file content
         */
        content: string;
    }
}
/**
 * Config files contents
 */
export type ConfigGuessResponse = {
    [key: string]: ConfigGuessResponse.item;
};
export declare namespace ConfigGuessResponse {
    interface item {
        /**
         * The file content
         */
        content: string;
    }
}
export interface ConfigRetrieveParams {
    /**
     * Path param
     */
    project?: string;
    /**
     * Query param: Branch name, defaults to "main".
     */
    branch?: string;
    /**
     * Query param
     */
    include?: string;
}
export interface ConfigGuessParams {
    /**
     * Path param
     */
    project?: string;
    /**
     * Body param: OpenAPI spec
     */
    spec: string;
    /**
     * Body param: Branch name
     */
    branch?: string;
}
export declare namespace Configs {
    export { type ConfigRetrieveResponse as ConfigRetrieveResponse, type ConfigGuessResponse as ConfigGuessResponse, type ConfigRetrieveParams as ConfigRetrieveParams, type ConfigGuessParams as ConfigGuessParams, };
}
//# sourceMappingURL=configs.d.mts.map