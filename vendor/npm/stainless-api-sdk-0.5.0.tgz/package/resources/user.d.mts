import { APIResource } from "../core/resource.mjs";
import { APIPromise } from "../core/api-promise.mjs";
import { RequestOptions } from "../internal/request-options.mjs";
export declare class User extends APIResource {
    /**
     * Retrieve the currently authenticated user's information.
     */
    retrieve(options?: RequestOptions): APIPromise<UserRetrieveResponse>;
}
export interface UserRetrieveResponse {
    id: string;
    email: string | null;
    github: UserRetrieveResponse.GitHub | null;
    name: string | null;
    object: 'user';
}
export declare namespace UserRetrieveResponse {
    interface GitHub {
        username: string;
    }
}
export declare namespace User {
    export { type UserRetrieveResponse as UserRetrieveResponse };
}
//# sourceMappingURL=user.d.mts.map