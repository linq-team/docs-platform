export interface Commit {
    repo: Commit.Repo;
    sha: string;
    stats: Commit.Stats | null;
    tree_oid: string | null;
}
export declare namespace Commit {
    interface Repo {
        branch: string;
        name: string;
        owner: string;
    }
    interface Stats {
        additions: number;
        deletions: number;
        total: number;
    }
}
export type FileInput = FileInput.Content | FileInput.URL;
export declare namespace FileInput {
    interface Content {
        /**
         * File content
         */
        content: string;
    }
    interface URL {
        /**
         * URL to fetch file content from
         */
        url: string;
    }
}
export type Target = 'node' | 'typescript' | 'python' | 'go' | 'java' | 'kotlin' | 'ruby' | 'terraform' | 'cli' | 'php' | 'csharp' | 'sql' | 'openapi';
//# sourceMappingURL=shared.d.ts.map