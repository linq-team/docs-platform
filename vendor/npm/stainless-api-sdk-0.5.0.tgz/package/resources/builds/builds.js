"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Builds = void 0;
const tslib_1 = require("../../internal/tslib.js");
const resource_1 = require("../../core/resource.js");
const DiagnosticsAPI = tslib_1.__importStar(require("./diagnostics.js"));
const diagnostics_1 = require("./diagnostics.js");
const TargetOutputsAPI = tslib_1.__importStar(require("./target-outputs.js"));
const target_outputs_1 = require("./target-outputs.js");
const pagination_1 = require("../../core/pagination.js");
const path_1 = require("../../internal/utils/path.js");
class Builds extends resource_1.APIResource {
    constructor() {
        super(...arguments);
        this.diagnostics = new DiagnosticsAPI.Diagnostics(this._client);
        this.targetOutputs = new TargetOutputsAPI.TargetOutputs(this._client);
    }
    /**
     * Create a build, on top of a project branch, against a given input revision.
     *
     * The project branch will be modified so that its latest set of config files
     * points to the one specified by the input revision.
     */
    create(params, options) {
        const { project = this._client.project, ...body } = params;
        return this._client.post('/v0/builds', { body: { project, ...body }, ...options });
    }
    /**
     * Retrieve a build by its ID.
     */
    retrieve(buildID, options) {
        return this._client.get((0, path_1.path) `/v0/builds/${buildID}`, options);
    }
    /**
     * List user-triggered builds for a given project.
     *
     * An optional revision can be specified to filter by config commit SHA, or hashes
     * of file contents.
     */
    list(params = {}, options) {
        const { project = this._client.project, ...query } = params ?? {};
        return this._client.getAPIList('/v0/builds', (pagination_1.Page), { query: { project, ...query }, ...options });
    }
    /**
     * Create two builds whose outputs can be directly compared with each other.
     *
     * Created builds _modify_ their project branches so that their latest sets of
     * config files point to the ones specified by the input revision.
     *
     * This endpoint is useful because a build has more inputs than the set of config
     * files it uses, so comparing two builds directly may return spurious differences.
     * Builds made via this endpoint are guaranteed to have differences arising from
     * the set of config files, and any custom code.
     */
    compare(params, options) {
        const { project = this._client.project, ...body } = params;
        return this._client.post('/v0/builds/compare', { body: { project, ...body }, ...options });
    }
}
exports.Builds = Builds;
Builds.Diagnostics = diagnostics_1.Diagnostics;
Builds.TargetOutputs = target_outputs_1.TargetOutputs;
//# sourceMappingURL=builds.js.map