import { APIResource } from "../../core/resource.js";
import * as Shared from "../shared.js";
import { APIPromise } from "../../core/api-promise.js";
import { RequestOptions } from "../../internal/request-options.js";
export declare class TargetOutputs extends APIResource {
    /**
     * Retrieve a method to download an output for a given build target.
     *
     * If the requested type of output is `source`, and the requested output method is
     * `url`, a download link to a tarball of the source files is returned. If the
     * requested output method is `git`, a Git remote, ref, and access token (if
     * necessary) is returned.
     *
     * Otherwise, the possible types of outputs are specific to the requested target,
     * and the output method _must_ be `url`. See the documentation for `type` for more
     * information.
     */
    retrieve(query: TargetOutputRetrieveParams, options?: RequestOptions): APIPromise<TargetOutputRetrieveResponse>;
}
export type TargetOutputRetrieveResponse = TargetOutputRetrieveResponse.URL | TargetOutputRetrieveResponse.Git;
export declare namespace TargetOutputRetrieveResponse {
    interface URL {
        output: 'url';
        target: Shared.Target;
        type: 'source' | 'dist' | 'wheel' | 'openapi-with-transforms' | 'openapi-with-code-samples' | 'openapi-sdk-spec';
        /**
         * URL for direct download
         */
        url: string;
    }
    interface Git {
        /**
         * Temporary GitHub access token
         */
        token: string;
        output: 'git';
        /**
         * Git reference (commit SHA, branch, or tag)
         */
        ref: string;
        target: Shared.Target;
        type: 'source' | 'dist' | 'wheel' | 'openapi-with-transforms' | 'openapi-with-code-samples' | 'openapi-sdk-spec';
        /**
         * URL to git remote
         */
        url: string;
    }
}
export interface TargetOutputRetrieveParams {
    /**
     * Build ID
     */
    build_id: string;
    /**
     * SDK language target name
     */
    target: 'node' | 'typescript' | 'python' | 'go' | 'java' | 'kotlin' | 'ruby' | 'terraform' | 'cli' | 'php' | 'csharp' | 'sql' | 'openapi';
    type: 'source' | 'dist' | 'wheel' | 'openapi-with-transforms' | 'openapi-with-code-samples' | 'openapi-sdk-spec';
    /**
     * Output format: url (download URL) or git (temporary access token).
     */
    output?: 'url' | 'git';
}
export declare namespace TargetOutputs {
    export { type TargetOutputRetrieveResponse as TargetOutputRetrieveResponse, type TargetOutputRetrieveParams as TargetOutputRetrieveParams, };
}
//# sourceMappingURL=target-outputs.d.ts.map