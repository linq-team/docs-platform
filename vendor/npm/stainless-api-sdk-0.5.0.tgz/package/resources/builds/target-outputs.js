"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.TargetOutputs = void 0;
const resource_1 = require("../../core/resource.js");
class TargetOutputs extends resource_1.APIResource {
    /**
     * Retrieve a method to download an output for a given build target.
     *
     * If the requested type of output is `source`, and the requested output method is
     * `url`, a download link to a tarball of the source files is returned. If the
     * requested output method is `git`, a Git remote, ref, and access token (if
     * necessary) is returned.
     *
     * Otherwise, the possible types of outputs are specific to the requested target,
     * and the output method _must_ be `url`. See the documentation for `type` for more
     * information.
     */
    retrieve(query, options) {
        return this._client.get('/v0/build_target_outputs', { query, ...options });
    }
}
exports.TargetOutputs = TargetOutputs;
//# sourceMappingURL=target-outputs.js.map