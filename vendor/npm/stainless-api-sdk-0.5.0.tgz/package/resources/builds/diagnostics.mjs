// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import { Page } from "../../core/pagination.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Diagnostics extends APIResource {
    /**
     * Get the list of diagnostics for a given build.
     *
     * If no language targets are specified, diagnostics for all languages are
     * returned.
     */
    list(buildID, query = {}, options) {
        return this._client.getAPIList(path `/v0/builds/${buildID}/diagnostics`, (Page), {
            query,
            ...options,
        });
    }
}
//# sourceMappingURL=diagnostics.mjs.map