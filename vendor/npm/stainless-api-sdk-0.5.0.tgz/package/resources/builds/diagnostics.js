"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Diagnostics = void 0;
const resource_1 = require("../../core/resource.js");
const pagination_1 = require("../../core/pagination.js");
const path_1 = require("../../internal/utils/path.js");
class Diagnostics extends resource_1.APIResource {
    /**
     * Get the list of diagnostics for a given build.
     *
     * If no language targets are specified, diagnostics for all languages are
     * returned.
     */
    list(buildID, query = {}, options) {
        return this._client.getAPIList((0, path_1.path) `/v0/builds/${buildID}/diagnostics`, (pagination_1.Page), {
            query,
            ...options,
        });
    }
}
exports.Diagnostics = Diagnostics;
//# sourceMappingURL=diagnostics.js.map