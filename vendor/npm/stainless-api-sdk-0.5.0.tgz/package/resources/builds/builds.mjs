// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../../core/resource.mjs";
import * as DiagnosticsAPI from "./diagnostics.mjs";
import { Diagnostics, } from "./diagnostics.mjs";
import * as TargetOutputsAPI from "./target-outputs.mjs";
import { TargetOutputs } from "./target-outputs.mjs";
import { Page } from "../../core/pagination.mjs";
import { path } from "../../internal/utils/path.mjs";
export class Builds extends APIResource {
    constructor() {
        super(...arguments);
        this.diagnostics = new DiagnosticsAPI.Diagnostics(this._client);
        this.targetOutputs = new TargetOutputsAPI.TargetOutputs(this._client);
    }
    /**
     * Create a build, on top of a project branch, against a given input revision.
     *
     * The project branch will be modified so that its latest set of config files
     * points to the one specified by the input revision.
     */
    create(params, options) {
        const { project = this._client.project, ...body } = params;
        return this._client.post('/v0/builds', { body: { project, ...body }, ...options });
    }
    /**
     * Retrieve a build by its ID.
     */
    retrieve(buildID, options) {
        return this._client.get(path `/v0/builds/${buildID}`, options);
    }
    /**
     * List user-triggered builds for a given project.
     *
     * An optional revision can be specified to filter by config commit SHA, or hashes
     * of file contents.
     */
    list(params = {}, options) {
        const { project = this._client.project, ...query } = params ?? {};
        return this._client.getAPIList('/v0/builds', (Page), { query: { project, ...query }, ...options });
    }
    /**
     * Create two builds whose outputs can be directly compared with each other.
     *
     * Created builds _modify_ their project branches so that their latest sets of
     * config files point to the ones specified by the input revision.
     *
     * This endpoint is useful because a build has more inputs than the set of config
     * files it uses, so comparing two builds directly may return spurious differences.
     * Builds made via this endpoint are guaranteed to have differences arising from
     * the set of config files, and any custom code.
     */
    compare(params, options) {
        const { project = this._client.project, ...body } = params;
        return this._client.post('/v0/builds/compare', { body: { project, ...body }, ...options });
    }
}
Builds.Diagnostics = Diagnostics;
Builds.TargetOutputs = TargetOutputs;
//# sourceMappingURL=builds.mjs.map