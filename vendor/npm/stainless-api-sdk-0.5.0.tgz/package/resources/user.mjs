// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
export class User extends APIResource {
    /**
     * Retrieve the currently authenticated user's information.
     */
    retrieve(options) {
        return this._client.get('/v0/user', options);
    }
}
//# sourceMappingURL=user.mjs.map