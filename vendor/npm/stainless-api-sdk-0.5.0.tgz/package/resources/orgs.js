"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.Orgs = void 0;
const resource_1 = require("../core/resource.js");
const path_1 = require("../internal/utils/path.js");
class Orgs extends resource_1.APIResource {
    /**
     * Retrieve an organization by name.
     */
    retrieve(org, options) {
        return this._client.get((0, path_1.path) `/v0/orgs/${org}`, options);
    }
    /**
     * List organizations accessible to the current authentication method.
     */
    list(options) {
        return this._client.get('/v0/orgs', options);
    }
}
exports.Orgs = Orgs;
//# sourceMappingURL=orgs.js.map