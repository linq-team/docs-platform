import { APIResource } from "../core/resource.mjs";
import { APIPromise } from "../core/api-promise.mjs";
import { RequestOptions } from "../internal/request-options.mjs";
export declare class Orgs extends APIResource {
    /**
     * Retrieve an organization by name.
     */
    retrieve(org: string, options?: RequestOptions): APIPromise<Org>;
    /**
     * List organizations accessible to the current authentication method.
     */
    list(options?: RequestOptions): APIPromise<OrgListResponse>;
}
export interface Org {
    display_name: string | null;
    enable_ai_commit_messages: boolean;
    object: 'org';
    slug: string;
}
export interface OrgListResponse {
    data: Array<Org>;
    has_more: boolean;
    next_cursor?: string;
}
export declare namespace Orgs {
    export { type Org as Org, type OrgListResponse as OrgListResponse };
}
//# sourceMappingURL=orgs.d.mts.map