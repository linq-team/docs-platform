"use strict";
// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
Object.defineProperty(exports, "__esModule", { value: true });
exports.User = void 0;
const resource_1 = require("../core/resource.js");
class User extends resource_1.APIResource {
    /**
     * Retrieve the currently authenticated user's information.
     */
    retrieve(options) {
        return this._client.get('/v0/user', options);
    }
}
exports.User = User;
//# sourceMappingURL=user.js.map