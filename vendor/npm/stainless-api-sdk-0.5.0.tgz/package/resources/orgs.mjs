// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { path } from "../internal/utils/path.mjs";
export class Orgs extends APIResource {
    /**
     * Retrieve an organization by name.
     */
    retrieve(org, options) {
        return this._client.get(path `/v0/orgs/${org}`, options);
    }
    /**
     * List organizations accessible to the current authentication method.
     */
    list(options) {
        return this._client.get('/v0/orgs', options);
    }
}
//# sourceMappingURL=orgs.mjs.map