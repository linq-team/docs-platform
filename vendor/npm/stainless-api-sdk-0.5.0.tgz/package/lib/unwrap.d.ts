/**
 * Unwrap a file value from a union type, like the build object's `documented_spec`.
 *
 * @example
 *   const build = await client.builds.retrieve(buildID);
 *   const spec = await Stainless.unwrapFile(build.documented_spec);
 */
export declare function unwrapFile(value: {
    type: 'content';
    content: string;
} | {
    type: 'url';
    url: string;
}): Promise<string>;
export declare function unwrapFile(value: {
    type: 'content';
    content: string;
} | {
    type: 'url';
    url: string;
} | null): Promise<string | null>;
//# sourceMappingURL=unwrap.d.ts.map