export declare const VERSION = "0.5.0";
//# sourceMappingURL=version.d.mts.map