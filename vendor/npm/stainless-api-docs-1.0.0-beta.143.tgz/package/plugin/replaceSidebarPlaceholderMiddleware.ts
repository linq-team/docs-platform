import { defineRouteMiddleware, StarlightRouteData } from '@astrojs/starlight/route-data';

import { RESOLVED_API_REFERENCE_PATH } from 'virtual:stl-starlight-virtual-module';
import { getAPIReferencePlaceholderItems } from './referencePlaceholderUtils';
import { parseRoute } from '@stainless-api/docs-ui/routing';
import path from 'path';
import { sidebars } from 'virtual:stl-starlight-reference-sidebars';

// this fn is loaded in the plugin via addRouteMiddleware

type SidebarEntry = StarlightRouteData['sidebar'][number];

const removeTrailingSlash = (value: string) => (value.endsWith('/') ? value.slice(0, -1) : value);

function markCurrentItems(sidebar: SidebarEntry[], currentSlug: string) {
  // IMPORTANT: we need to clone the sidebar to avoid mutating the original sidebar
  const mutableSidebarInstance = structuredClone(sidebar);
  const normalizedCurrentSlug = removeTrailingSlash(currentSlug);

  function recursiveMarkCurrent(entries: SidebarEntry[]) {
    for (const entry of entries) {
      if (entry.type === 'link') {
        entry.isCurrent = removeTrailingSlash(entry.href) === normalizedCurrentSlug;
      }
      if (entry.type === 'group') {
        recursiveMarkCurrent(entry.entries);
      }
    }
  }
  recursiveMarkCurrent(mutableSidebarInstance);

  return mutableSidebarInstance;
}

export const onRequest = defineRouteMiddleware((context) => {
  // if using content collection schema, use: context.locals.starlightRoute.entry.data.stainlessStarlight
  // this worked without collections but relied on hijacking starlightRoute: context.props.frontmatter.stainlessStarlight
  const slug = path.posix.join(import.meta.env.BASE_URL ?? '', `/${context.locals.starlightRoute.id}`); // same as .slug but not deprecated

  context.locals.starlightRoute._stlStarlight = {
    basePath: RESOLVED_API_REFERENCE_PATH,
  };

  const apiReferencePlaceholderItems = getAPIReferencePlaceholderItems(context.locals.starlightRoute.sidebar);

  const { language } = parseRoute(RESOLVED_API_REFERENCE_PATH, slug);

  for (const item of apiReferencePlaceholderItems) {
    const entries = sidebars.find((sb) => sb.id === item.sidebarId && sb.language === language)?.entries;
    if (!entries) {
      throw new Error(`Expected sidebar entries for sidebar ID ${item.sidebarId} and language ${language}`);
    }

    item.group.splice(item.index, 1, ...entries);
  }

  context.locals.starlightRoute.sidebar = markCurrentItems(context.locals.starlightRoute.sidebar, slug);
});
