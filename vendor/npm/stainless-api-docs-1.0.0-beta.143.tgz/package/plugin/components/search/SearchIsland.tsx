import { useMemo } from 'react';
import { RESOLVED_API_REFERENCE_PATH, HIGHLIGHT_THEMES } from 'virtual:stl-starlight-virtual-module';
import { parseRoute, generateRoute } from '@stainless-api/docs-ui/routing';
import { SearchModal } from '@stainless-api/docs-search';
import * as Markdoc from '@markdoc/markdoc';
import { createHighlighter } from 'shiki';
import type { BundledLanguage, BundledTheme, HighlighterGeneric } from 'shiki';

import {
  DocsProvider,
  type MarkdownContextValue,
  NavigationProvider,
  SuspensefulMarkdownProvider,
} from '@stainless-api/docs-ui/contexts';
import { ComponentProvider } from '@stainless-api/docs-ui/contexts/component';
import { SearchProvider } from '@stainless-api/docs-search/context';
import type { SearchSettings } from '@stainless-api/docs-search/types';

declare global {
  var __docsSearchShikiSingleton: Promise<HighlighterGeneric<BundledLanguage, BundledTheme>> | undefined;
}
function getHighlighter() {
  if (!globalThis.__docsSearchShikiSingleton) {
    globalThis.__docsSearchShikiSingleton = createHighlighter({
      themes: ['github-dark'],
      langs: ['typescript', 'python', 'go', 'java', 'kotlin', 'ruby'],
    });
  }
  return globalThis.__docsSearchShikiSingleton;
}

async function createMarkdownRenderer(): Promise<MarkdownContextValue> {
  const highlighter = await getHighlighter();
  const markdocConfig: Markdoc.Config = {
    nodes: {
      document: { ...Markdoc.nodes.document, render: '' },
      fence: {
        ...Markdoc.nodes.fence,
        transform(node, config) {
          const attributes = node.transformAttributes(config);
          if (typeof node.attributes.language !== 'string' || typeof node.attributes.content !== 'string') {
            throw new Error('Expected language and content to be strings');
          }
          const lang = node.attributes.language === 'node' ? 'typescript' : node.attributes.language;
          const code = highlighter.codeToTokens(node.attributes.content, {
            // @ts-expect-error - TODO: narrowing
            lang,
            theme: 'github-dark',
          });

          return new Markdoc.Tag(
            'pre',
            attributes,
            code.tokens.map(
              (line) =>
                new Markdoc.Tag('span', { class: 'line' }, [
                  ...line.map(
                    (token) => new Markdoc.Tag('span', { style: `color:${token.color}` }, [token.content]),
                  ),
                  new Markdoc.Tag('span', { class: 'nl' }, ['\n']),
                ]),
            ),
          );
        },
      },
      link: {
        ...Markdoc.nodes.link,
        transform(node, config) {
          const children = node.transformChildren(config);
          const attrs = node.transformAttributes(config);
          if (typeof attrs['href'] !== 'string') throw new Error('Expected href to be a string');
          const href = attrs['href'].replace('docs://BASE_PATH', RESOLVED_API_REFERENCE_PATH);
          return new Markdoc.Tag(this.render, { ...attrs, href }, children);
        },
      },
    },
  };

  return {
    render: (content: string) => {
      const ast = Markdoc.parse(content);
      const transformed = Markdoc.transform(ast, markdocConfig);
      return Markdoc.renderers.html(transformed);
    },
    highlight: (content: string, language: string) => {
      return highlighter.codeToHtml(content, {
        lang: language ?? 'javascript',
        themes: HIGHLIGHT_THEMES || {},
      });
    },
  };
}

export function DocsSearch({ settings, currentPath }: { settings: SearchSettings; currentPath: string }) {
  const rendererPromise = useMemo(() => createMarkdownRenderer(), []);
  const { stainlessPath, language } = parseRoute(RESOLVED_API_REFERENCE_PATH, currentPath);
  // eslint-disable-next-line turbo/no-undeclared-env-vars
  const pageFind = import.meta.env.DEV
    ? undefined
    : `${import.meta.env.BASE_URL}/pagefind/pagefind.js`.replace(/\/+/g, '/');

  function handleSelect(selectedPath: string) {
    const url = selectedPath.startsWith('/')
      ? selectedPath
      : generateRoute(RESOLVED_API_REFERENCE_PATH, language, selectedPath);
    if (url) window.location.href = url;
  }

  return (
    <DocsProvider spec={null} language={language}>
      <ComponentProvider>
        <NavigationProvider basePath="/" selectedPath={stainlessPath}>
          <SuspensefulMarkdownProvider value={rendererPromise}>
            <SearchProvider onSelect={handleSelect} pageFind={pageFind} settings={settings}>
              <div className="stldocs-root">
                <SearchModal id="stldocs-search" />
              </div>
            </SearchProvider>
          </SuspensefulMarkdownProvider>
        </NavigationProvider>
      </ComponentProvider>
    </DocsProvider>
  );
}
