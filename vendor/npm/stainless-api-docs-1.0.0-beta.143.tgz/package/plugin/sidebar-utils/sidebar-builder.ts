import type * as SDKJSON from '@stainless/sdk-json';
import { generateRoute, walkTree, type DocsLanguage } from '@stainless-api/docs-ui/routing';
import type { StarlightRouteData } from '@astrojs/starlight/route-data';
import { isResourceEntirelyUnsupported } from '@stainless-api/docs-ui/languages/terraform';

function makeMethodOrResourceKey(entry: SDKJSON.Method | SDKJSON.Resource): string {
  if (entry.kind === 'http_method') {
    if (entry.endpoint && entry.endpoint !== '') {
      return entry.endpoint;
    }
    return entry.stainlessPath;
  }
  if (entry.kind === 'resource') {
    return entry.stainlessPath;
  }
  throw new Error(`Unknown entry kind ${JSON.stringify(entry)}`);
}

function isResourceNonEmpty(resource: SDKJSON.Resource) {
  return (
    Object.keys(resource.methods ?? {}).length > 0 ||
    Object.keys(resource.subresources ?? {}).length > 0 ||
    Object.keys(resource.models ?? {}).length > 0
  );
}

interface UserSidebarConfigItem {
  label: string;
  badge: StarlightRouteData['sidebar'][number]['badge'];
}

type MethodMetadata = {
  deprecated: boolean;
  methodName: string;
  title: string;
  summary: string | undefined;
  description: string | undefined;
  httpMethod: string;
};
interface UserSidebarMethodPage extends UserSidebarConfigItem {
  /**
   * The kind is the type of the item that will be generated.
   */
  kind: 'method_page';
  /**
   * The key + kind is how Stainless identifies the item to build the final sidebar.
   * DO NOT modify the key or kind of the item.
   * You may change any other properties like the label. You may also completely remove the item.
   *
   * Example: post v1/{accounts}/charges
   * The key is identical to the endpoint specified in your Stainless config file.
   */
  key: string;
  metadata: MethodMetadata;
}

interface UserSidebarResourceOverviewPage extends UserSidebarConfigItem {
  /**
   * The kind is the type of the item that will be generated.
   */
  kind: 'resource_overview_page';
  /**
   * The key + kind is how Stainless identifies the item to build the final sidebar.
   * DO NOT modify the key or kind of the item.
   * You may change any other properties like the label. You may also completely remove the item.
   *
   * Example: #/resources/accounts/subresources/charges
   * The key is the path to the resource specified in your Stainless config file.
   */
  key: string;
  metadata: {
    subResourceCount: number;
    methodCount: number;
    modelCount: number;
  };
}

interface UserSidebarAPIOverviewPage extends UserSidebarConfigItem {
  /**
   * The kind is the type of the item that will be generated.
   */
  kind: 'api_overview_page';
  /**
   * The key + kind is how Stainless identifies the item to build the final sidebar.
   * DO NOT modify the key or kind of the item.
   * You may change any other properties like the label. You may also completely remove the item.
   *
   * Example: #/resources/accounts/subresources/charges
   * The key is the path to the resource specified in your Stainless config file.
   */
  key: 'api_overview_page';
}

interface ReferenceSidebarGroup extends UserSidebarConfigItem {
  kind: 'group';
  label: string;
  /**
   * Whether the group should be collapsed by default.
   */
  collapsed: boolean;
  /**
   * If this group is a group for a resource, this will be the key of the resource.
   */
  resourceGroupKey?: string;
  entries: ReferenceSidebarConfigItem[];
}

export type ReferenceSidebarConfigItem =
  | UserSidebarMethodPage
  | UserSidebarResourceOverviewPage
  | UserSidebarAPIOverviewPage
  | ReferenceSidebarGroup;

export type ReferenceSidebarConfigGenerateOptions = {
  /**
   * Whether to include a "shared" page for models defined at the client level in the sidebar.
   * Defaults to `false`.
   */
  includeSharedModels?: boolean;

  /**
   * Whether to exclude the resource overview page for each resource in the sidebar.
   * Defaults to `false`.
   */
  excludeResourceOverviewPages?: boolean;
};

export type GeneratedSidebarConfig = {
  options?: ReferenceSidebarConfigGenerateOptions | undefined;
  transformFn?: (
    sidebar: ReferenceSidebarConfigItem[],
    language: DocsLanguage,
  ) => ReferenceSidebarConfigItem[] | void;
};

function countKeys(obj?: Record<string, unknown>) {
  return Object.keys(obj ?? {}).length;
}

type HasIdent<T> = T extends { ident: unknown } ? T : never;
type MethodDecl = HasIdent<SDKJSON.LanguageDeclNodes[SDKJSON.SpecLanguage]>;

function makeAPIOverviewPage(): UserSidebarAPIOverviewPage {
  return {
    kind: 'api_overview_page',
    label: 'Overview',
    key: 'api_overview_page',
    badge: undefined,
  };
}

function pullOutSharedModelsResource(resources: SDKJSON.Resource[]): {
  resources: SDKJSON.Resource[];
  sharedModelsResource: SDKJSON.Resource | null;
} {
  let sharedModelsResource: SDKJSON.Resource | null = null;
  const remainingResources = resources.filter((r) => {
    if (r.configRef === '#/resources/$shared') {
      sharedModelsResource = r;
      return false;
    }
    return true;
  });

  return {
    resources: remainingResources,
    sharedModelsResource,
  };
}

export class SidebarConfigItemsBuilder {
  private getMethodDeclForLanguage(entry: SDKJSON.Method): MethodDecl | null {
    const decls = this.spec.decls[this.language] ?? {};
    const decl = decls[entry.stainlessPath];
    if (decl !== undefined) {
      if ('ident' in decl && decl.ident !== undefined) {
        return decl as MethodDecl;
      }
    }
    return null;
  }

  private isWebhookResource(resource: SDKJSON.Resource): boolean {
    return resource.stainlessPath === '(resource) webhooks';
  }

  private toResourceOverviewPage(entry: SDKJSON.Resource): UserSidebarResourceOverviewPage {
    return {
      kind: 'resource_overview_page',
      label: this.isWebhookResource(entry) ? 'Events' : 'Overview',
      key: makeMethodOrResourceKey(entry),
      badge: undefined,
      metadata: {
        subResourceCount: countKeys(entry.subresources),
        methodCount: countKeys(entry.methods),
        modelCount: countKeys(entry.models),
      },
    };
  }

  private toMethodPage(entry: SDKJSON.Method, decl: MethodDecl): UserSidebarMethodPage {
    return {
      kind: 'method_page',
      label: entry.title,
      key: makeMethodOrResourceKey(entry),
      badge: undefined,
      metadata: {
        deprecated: Boolean(entry.deprecated),
        methodName: this.language === 'http' ? entry.name : decl.ident,
        title: entry.title,
        summary: entry.summary,
        description: entry.description,
        httpMethod: entry.httpMethod,
      },
    };
  }

  private generateResourceGroup(resource: SDKJSON.Resource, collapsed: boolean): ReferenceSidebarGroup {
    const entries: ReferenceSidebarConfigItem[] = [];
    // even if we aren't generating resource overview pages, we want to generate them for webhooks
    if (!this.options?.excludeResourceOverviewPages || this.isWebhookResource(resource)) {
      entries.push(this.toResourceOverviewPage(resource));
    }
    const methods = Object.values(resource.methods ?? {});
    const methodPages: UserSidebarMethodPage[] = [];
    for (const m of methods) {
      const langDecl = this.getMethodDeclForLanguage(m);
      if (langDecl) {
        methodPages.push(this.toMethodPage(m, langDecl));
      }
    }
    entries.push(...methodPages);

    const subresources = Object.values(resource.subresources ?? {});
    const subresourceGroups: ReferenceSidebarGroup[] = [];
    for (const sub of subresources) {
      if (isResourceNonEmpty(sub)) {
        subresourceGroups.push(this.generateResourceGroup(sub, true));
      }
    }
    entries.push(...subresourceGroups);

    return {
      kind: 'group',
      badge: undefined,
      label: resource.title,
      resourceGroupKey: makeMethodOrResourceKey(resource),
      entries,
      collapsed,
    };
  }

  private generateTerraformItems(resources: SDKJSON.Resource[]) {
    const entries: ReferenceSidebarConfigItem[] = [];

    for (const resource of resources) {
      if (isResourceEntirelyUnsupported(resource, this.spec.decls['terraform'])) {
        continue;
      }
      entries.push({
        kind: 'resource_overview_page',
        label: resource.title,
        key: makeMethodOrResourceKey(resource),
        badge: undefined,
        metadata: {
          subResourceCount: countKeys(resource.subresources),
          methodCount: countKeys(resource.methods),
          modelCount: countKeys(resource.models),
        },
      });
    }
    return entries;
  }

  public generateItems(): ReferenceSidebarConfigItem[] {
    const resourceMap = this.spec.resources;
    const { resources, sharedModelsResource } = pullOutSharedModelsResource(Object.values(resourceMap ?? {}));

    let entries: ReferenceSidebarConfigItem[];

    if (this.language === 'terraform') {
      // Handle Terraform specifically
      // In TF, we only render the top level resource, not the subresources.
      entries = this.generateTerraformItems(resources);
    } else {
      entries = resources.filter(isResourceNonEmpty).map((r) => {
        return this.generateResourceGroup(r, false);
      });
    }

    const includeSharedModels = this.options?.includeSharedModels ?? false;
    if (includeSharedModels && sharedModelsResource) {
      entries.unshift(this.toResourceOverviewPage(sharedModelsResource));
    }

    entries.unshift(makeAPIOverviewPage());

    return entries;
  }

  constructor(
    private spec: SDKJSON.Spec,
    private language: DocsLanguage,
    private options?: ReferenceSidebarConfigGenerateOptions,
  ) {}
}

type SidebarEntry = StarlightRouteData['sidebar'][number];

// This allows us to be a bit more forgiving to the user.
// As long as they don't modify the key, we can still find the item.

function getResourceOrMethod(spec: SDKJSON.Spec, endpointOrConfigRef: string) {
  for (const entry of walkTree(spec, false)) {
    if (entry.data.kind === 'model') {
      continue;
    }
    if (makeMethodOrResourceKey(entry.data) === endpointOrConfigRef) {
      return entry;
    }
  }
  return null;
}

function forceGenerateRoute({
  basePath,
  stainlessPath,
  language,
}: {
  basePath: string;
  stainlessPath: string;
  language: DocsLanguage;
}) {
  const route = generateRoute(basePath, language, stainlessPath);
  if (!route) {
    throw new Error(`Route for path ${stainlessPath} failed to generate`);
  }
  return route;
}

type ToStarlightSidebarParams = {
  basePath: string;
  spec: SDKJSON.Spec;
  entries: ReferenceSidebarConfigItem[];
  currentLanguage: DocsLanguage;
};

export function toStarlightSidebar({
  basePath,
  spec,
  entries,
  currentLanguage,
}: ToStarlightSidebarParams): SidebarEntry[] {
  const starlightEntries: SidebarEntry[] = [];

  for (const entry of entries) {
    if (entry.kind === 'api_overview_page') {
      const readmeSlug = currentLanguage === 'http' ? basePath : `${basePath}/${currentLanguage}`;

      starlightEntries.push({
        type: 'link',
        href: readmeSlug,
        label: entry.label,
        isCurrent: false,
        badge: entry.badge,
        attrs: {
          'data-stldocs-overview': 'readme',
        },
      });
    } else if (entry.kind === 'resource_overview_page' || entry.kind === 'method_page') {
      const resourceOrMethod = getResourceOrMethod(spec, entry.key);
      if (!resourceOrMethod) {
        throw new Error(
          `Resource or method not found for key ${entry.key} Make sure you don't modify the key.`,
        );
      }
      const route = forceGenerateRoute({
        basePath,
        stainlessPath: resourceOrMethod.data.stainlessPath,
        language: currentLanguage,
      });

      if (resourceOrMethod.data.kind === 'http_method') {
        starlightEntries.push({
          type: 'link',
          href: route,
          label: entry.label,
          isCurrent: false,
          badge: entry.badge,
          attrs: {
            'data-stldocs-method': resourceOrMethod.data.httpMethod,
          },
        });
      } else if (resourceOrMethod.data.kind === 'resource') {
        starlightEntries.push({
          type: 'link',
          href: route,
          label: entry.label,
          isCurrent: false,
          badge: entry.badge,
          attrs: {
            // TODO: @Ryan: is data.name unique? This is what we used before so I'm not changing, but I am curious.
            'data-stldocs-overview': resourceOrMethod.data.name,
          },
        });
      } else {
        throw new Error(`Unknown entry kind ${JSON.stringify(entry)}`);
      }
    } else if (entry.kind === 'group') {
      if (entry.resourceGroupKey) {
        const resourceOrMethod = getResourceOrMethod(spec, entry.resourceGroupKey);
        // Skip pushing the group if if the resource it represents is not available in the current language.
        // This occurs when SDK generation for the current language is skipped in the Stainless config for that resource.
        if (resourceOrMethod?.data?.kind === 'resource' && !resourceOrMethod?.data?.[currentLanguage]) {
          continue;
        }
      }
      starlightEntries.push({
        type: 'group',
        label: entry.label,
        entries: toStarlightSidebar({
          basePath,
          spec,
          entries: entry.entries,
          currentLanguage,
        }),
        collapsed: entry.collapsed,
        badge: entry.badge,
      });
    } else {
      throw new Error(`Unknown entry kind ${JSON.stringify(entry)}`);
    }
  }
  return starlightEntries;
}
