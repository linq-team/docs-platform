import { getPageLoadEvent } from '../helpers/getPageLoadEvent.ts';

document.addEventListener(getPageLoadEvent(), () => {
  document.querySelectorAll('.stldocs-snippet-response-tab-item').forEach((tab) => {
    tab.addEventListener('click', () => {
      document
        .querySelectorAll('.stldocs-snippet-response-tab-item')
        .forEach((t) => t.classList.remove('stldocs-snippet-response-tab-item-active'));
      document
        .querySelectorAll('.stldocs-snippet-response-pane')
        .forEach((p) => p.classList.remove('stldocs-snippet-response-pane-active'));

      const panelId = (tab as HTMLButtonElement).dataset.snippetResponseTabId;

      if (!panelId) {
        console.error(`No panel found for tab: ${tab.outerHTML}`);
        return;
      }
      document
        .querySelectorAll(`[data-snippet-response-pane-id="${panelId}"]`)
        .forEach((p) => p.classList.add('stldocs-snippet-response-pane-active'));
      document.querySelectorAll(`[data-snippet-response-tab-id="${panelId}"]`).forEach((p) => {
        p.classList.add('stldocs-snippet-response-tab-item-active');
        p.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      });
    });
  });

  document.getElementById('stl-snippet-expand-button')?.addEventListener('click', (e) => {
    const btn = e.currentTarget as HTMLButtonElement;

    const collapsedDiv = document.querySelector('.stl-snippet-code-is-collapsed');
    const expandedDiv = document.querySelector('.stl-snippet-code-is-expanded');

    // We need to use javascript for height animations due to having dynamic heights based on snippet size.
    const animateHeight = (el: HTMLElement, expand: boolean) => {
      const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (prefersReduced) {
        el.classList.toggle('stl-snippet-code-is-expanded', expand);
        el.classList.toggle('stl-snippet-code-is-collapsed', !expand);
        return;
      }

      // This is a bit funky, but it animates pretty smooth.
      // 1. Toggle to new state so we can measure the target height
      // 2. Reset to starting height to trigger transition
      el.style.height = '';
      el.style.overflowY = '';
      const startHeight = el.getBoundingClientRect().height;
      el.classList.toggle('stl-snippet-code-is-expanded', expand);
      el.classList.toggle('stl-snippet-code-is-collapsed', !expand);

      const endHeight = el.getBoundingClientRect().height;

      const onEnd = (e: TransitionEvent) => {
        if (e.propertyName !== 'height') return;
        el.style.height = '';
        el.style.overflowY = '';
        el.removeEventListener('transitionend', onEnd);
      };
      el.addEventListener('transitionend', onEnd);

      // Set initial height
      el.style.height = `${startHeight}px`;
      el.style.overflowY = 'hidden';

      // Force layout recalculation
      el.getBoundingClientRect();

      // Start transition to end state
      el.style.height = `${endHeight}px`;
    };

    if (collapsedDiv instanceof HTMLElement) {
      if (collapsedDiv) {
        collapsedDiv.querySelector('.shiki')?.setAttribute('style', `counter-reset: codeblock-line 0`);
      }
      animateHeight(collapsedDiv, true);
      btn.textContent = 'Show less';
      return;
    }

    if (expandedDiv instanceof HTMLElement) {
      const dataSnippetExpandedOffset = expandedDiv?.dataset.snippetExpandedOffset;
      if (dataSnippetExpandedOffset) {
        const offset = parseInt(dataSnippetExpandedOffset, 10);
        expandedDiv
          .querySelector('.shiki')
          ?.setAttribute('style', `counter-reset: codeblock-line ${Math.max(offset - 1, 0)}`);
      }
      animateHeight(expandedDiv, false);
      btn.textContent = 'Show more';
    }
  });

  document.querySelectorAll('[data-stldocs-multi-snippet-container]').forEach((container) => {
    const radios = container.querySelectorAll<HTMLInputElement>('input[type="radio"]');
    const panes = container.querySelectorAll<HTMLDivElement>('[data-stldocs-multi-snippet-id]');

    radios.forEach((radio) => {
      radio.addEventListener('change', (e) => {
        if (!(e.target instanceof HTMLInputElement)) return;
        if (e.target.checked) {
          const selectedIndex = e.target.value;
          panes.forEach((pane) => {
            pane.classList.toggle(
              'stldocs-snippet-multi-pane-active',
              pane.dataset.stldocsMultiSnippetId === selectedIndex,
            );
          });
          e.target.parentElement?.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        }
      });
    });
  });
});
