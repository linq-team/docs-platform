import type { AstroIntegration } from 'astro';
import { readFile, writeFile } from 'fs/promises';
import { toMarkdown } from './toMarkdown';
import { resolveSrcFile } from '../../resolveSrcFile';
import { getSharedLogger } from '../../shared/getSharedLogger';
import { bold } from '../../shared/terminalUtils';
import { getProsePages } from '../../shared/getProsePages';

export function stainlessDocsMarkdownRenderer({
  apiReferenceBasePath,
}: {
  apiReferenceBasePath: string | null;
}): AstroIntegration {
  return {
    name: 'stl-docs-md',
    hooks: {
      'astro:config:setup': ({ addMiddleware }) => {
        addMiddleware({
          entrypoint: resolveSrcFile('/stl-docs/proseMarkdown/proseMarkdownMiddleware.ts'),
          order: 'post',
        });
      },
      'astro:build:done': async ({ logger: localLogger, dir }) => {
        const logger = getSharedLogger({ fallback: localLogger });
        const outputBasePath = dir.pathname;
        const pagesToRender = await getProsePages({ apiReferenceBasePath, outputBasePath });

        logger.info(bold(`Building ${pagesToRender.length} Markdown pages for prose content`));

        let completedCount = 0;

        for (const absHtmlPath of pagesToRender) {
          const txt = await readFile(absHtmlPath, 'utf-8');
          const md = await toMarkdown(txt);
          if (md) {
            const absMdPath = absHtmlPath.replace('.html', '.md');
            await writeFile(absMdPath, md, 'utf-8');

            completedCount++;

            const relHtmlPath = absHtmlPath.replace(outputBasePath, '');
            const relMdPath = absMdPath.replace(outputBasePath, '');

            logger.info(`(${completedCount}/${pagesToRender.length}) ${relHtmlPath} -> ${relMdPath}`);
          } else {
            logger.error(`Failed to render ${absHtmlPath} as Markdown`);
            process.exit(1);
          }
        }
      },
    },
  };
}
