import type { AstroIntegration } from 'astro';
import type { StarlightPlugin } from '@astrojs/starlight/types';

const disableCalloutSyntaxAstroIntegration = {
  name: 'stl-starlight-remove-callout-syntax',
  hooks: {
    'astro:config:setup': ({ config: astroConfig }) => {
      // Remove starlight callout syntax in favor of our own callout component
      // updateConfig always deeply merges arrays so we need to mutate remarkPlugins directly
      // in order to remove plugins that starlight added
      astroConfig.markdown.remarkPlugins = astroConfig.markdown.remarkPlugins.filter((plugin, i, arr) => {
        if (typeof plugin !== 'function') return true;
        // remove:
        // 1. remarkDirective plugin
        if (plugin.name === 'remarkDirective') return false;
        // 2. directly followed by remarkAsides plugin (inner function named 'attacher')
        if (plugin.name === 'attacher') {
          const prev = arr[i - 1];
          if (typeof prev === 'function' && prev.name === 'remarkDirective') return false;
        }
        // 3. remarkDirectivesRestoration plugin
        if (plugin.name === 'remarkDirectivesRestoration') return false;
        return true;
      });
    },
  },
} satisfies AstroIntegration;

export const disableCalloutSyntaxStarlightPlugin = {
  name: 'stl-starlight-remove-callout-syntax',
  hooks: {
    'config:setup': ({ addIntegration }) => {
      addIntegration(disableCalloutSyntaxAstroIntegration);
    },
  },
} satisfies StarlightPlugin;
