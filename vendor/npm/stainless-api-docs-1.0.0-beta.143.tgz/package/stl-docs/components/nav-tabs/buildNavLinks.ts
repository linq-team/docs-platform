import type { StarlightRouteData } from '@astrojs/starlight/route-data';
import { TABS } from 'virtual:stl-docs-virtual-module';
import type { StarlightRouteWithStlDocs } from '../../tabsMiddleware';

export function buildNavLinks(starlightRoute: StarlightRouteData) {
  const routeData: StarlightRouteWithStlDocs = starlightRoute;
  const activeTabIndex = routeData?._stlDocs?.activeTabIndex;

  const navLinks = TABS.map((item, index) => ({
    ...item,
    active: index === activeTabIndex,
  })).filter((item) => !item.hidden);

  return navLinks;
}

export type NavLink = ReturnType<typeof buildNavLinks>[number];
