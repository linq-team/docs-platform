import type { AstroConfig } from 'astro';
import type { Defined } from './loadStlDocsConfig';
import { fontProviders } from 'astro/config';
import type { FontPreloadFilter } from 'astro:assets';

type AstroFontConfigEntry = Defined<AstroConfig['fonts']>[number];

// Apply Omit to each member of the union while preserving union structure
type PreloadFilter = { preload?: FontPreloadFilter };
type StlDocsFontConfigEntry = (AstroFontConfigEntry extends infer T
  ? T extends unknown
    ? Omit<T, 'cssVariable'>
    : never
  : never) &
  PreloadFilter;

export type StlDocsFontConfig = {
  primary?: StlDocsFontConfigEntry;
  heading?: StlDocsFontConfigEntry;
  mono?: StlDocsFontConfigEntry;
  additional?: (AstroFontConfigEntry & PreloadFilter)[];
};
const latinFeatureSettings = "'ss01' on, 'ss03' on, 'ss04' on, 'ss06' on, 'ss08' on";
/* prettier-ignore */
const latinUnicodeRange: readonly string[] = ['U+0000-00FF', 'U+0131', 'U+0152-0153', 'U+02BB-02BC', 'U+02C6', 'U+02DA', 'U+02DC', 'U+0304', 'U+0308', 'U+0329', 'U+2000-206F', 'U+20AC', 'U+2122', 'U+2191', 'U+2193', 'U+2212', 'U+2215', 'U+FEFF', 'U+FFFD'];
// /* prettier-ignore */
// const latinExtUnicodeRange: readonly string[] = ['U+0100-02BA', 'U+02BD-02C5', 'U+02C7-02CC', 'U+02CE-02D7', 'U+02DD-02FF', 'U+0304', 'U+0308', 'U+0329', 'U+1D00-1DBF', 'U+1E00-1E9F', 'U+1EF2-1EFF', 'U+2020', 'U+20A0-20AB', 'U+20AD-20C0', 'U+2113', 'U+2C60-2C7F', 'U+A720-A7FF'];

export function getFontRoles(fonts: StlDocsFontConfig | undefined) {
  if (!fonts) {
    return {};
  }
  const fontConfigs: {
    primary?: { cssVariable: string; preload?: FontPreloadFilter };
    heading?: { cssVariable: string; preload?: FontPreloadFilter };
    mono?: { cssVariable: string; preload?: FontPreloadFilter };
    additional?: { cssVariable: string; preload?: FontPreloadFilter }[];
  } = {};
  if (fonts.primary) {
    fontConfigs['primary'] = {
      cssVariable: '--stl-typography-font' as const,
      preload: fonts.primary.preload ?? [{ style: 'normal' }],
    };
  }
  if (fonts.heading) {
    fontConfigs['heading'] = {
      cssVariable: '--stl-typography-font-heading' as const,
      preload: fonts.heading.preload ?? [{ style: 'normal' }],
    };
  }
  if (fonts.mono) {
    fontConfigs['mono'] = {
      cssVariable: '--stl-typography-font-mono' as const,
      preload: fonts.mono.preload ?? [{ style: 'normal' }],
    };
  }
  if (fonts.additional) {
    fontConfigs['additional'] = fonts.additional.map((font) => ({
      cssVariable: font.cssVariable,
      preload: font.preload ?? [{ style: 'normal' }],
    }));
  }
  return fontConfigs;
}

export function normalizeFonts(fonts: StlDocsFontConfig | undefined): StlDocsFontConfig {
  const defaultPrimary: StlDocsFontConfigEntry = {
    provider: fontProviders.local(),
    name: 'Geist',
    display: 'swap',
    preload: [
      {
        weight: '100 900',
        style: 'normal',
      },
    ],
    options: {
      variants: [
        {
          weight: '100 900',
          style: 'normal',
          src: [new URL('../assets/fonts/geist/geist-latin.woff2', import.meta.url)],
          unicodeRange: latinUnicodeRange,
          featureSettings: latinFeatureSettings,
        },
        {
          weight: '100 900',
          style: 'italic',
          src: [new URL('../assets/fonts/geist/geist-italic-latin.woff2', import.meta.url)],
          unicodeRange: latinUnicodeRange,
          featureSettings: latinFeatureSettings,
        },
        // {
        //   weight: '100 900',
        //   style: 'normal',
        //   src: [new URL('../assets/fonts/geist/geist-latin-ext.woff2', import.meta.url)],
        //   unicodeRange: latinExtUnicodeRange,
        //   featureSettings: latinFeatureSettings,
        // },
        // {
        //   weight: '100 900',
        //   style: 'italic',
        //   src: [new URL('../assets/fonts/geist/geist-italic-latin-ext.woff2', import.meta.url)],
        //   unicodeRange: latinExtUnicodeRange,
        //   featureSettings: latinFeatureSettings,
        // },
      ],
    },
  };
  const defaultMono: StlDocsFontConfigEntry = {
    provider: fontProviders.local(),
    name: 'Geist Mono',
    display: 'swap',
    preload: [
      {
        weight: '100 900',
        style: 'normal',
      },
    ],
    options: {
      variants: [
        {
          weight: '100 900',
          style: 'normal',
          src: [new URL('../assets/fonts/geist/geist-mono-latin.woff2', import.meta.url)],
          unicodeRange: latinUnicodeRange,
        },
        {
          weight: '100 900',
          style: 'italic',
          src: [new URL('../assets/fonts/geist/geist-mono-italic-latin.woff2', import.meta.url)],
          unicodeRange: latinUnicodeRange,
        },
        // {
        //   weight: '100 900',
        //   style: 'normal',
        //   src: [new URL('../assets/fonts/geist/geist-mono-latin-ext.woff2', import.meta.url)],
        //   unicodeRange: latinExtUnicodeRange,
        // },
        // {
        //   weight: '100 900',
        //   style: 'italic',
        //   src: [new URL('../assets/fonts/geist/geist-mono-italic-latin-ext.woff2', import.meta.url)],
        //   unicodeRange: latinExtUnicodeRange,
        // },
      ],
    },
  };

  return {
    primary: fonts?.primary ?? defaultPrimary,
    heading: fonts?.heading ?? undefined,
    mono: fonts?.mono ?? defaultMono,
    additional: fonts?.additional ?? [],
  };
}

// Normalize fonts for the Astro config
export function flattenFonts(fonts: StlDocsFontConfig | undefined): AstroFontConfigEntry[] {
  if (!fonts) {
    return [];
  }
  const fontConfigs: AstroFontConfigEntry[] = [];
  if (fonts.primary) {
    fontConfigs.push({
      ...fonts.primary,
      cssVariable: '--stl-typography-font' as const,
    });
  }
  if (fonts.heading) {
    fontConfigs.push({
      ...fonts.heading,
      cssVariable: '--stl-typography-font-heading' as const,
    });
  }
  if (fonts.mono) {
    fontConfigs.push({
      ...fonts.mono,
      cssVariable: '--stl-typography-font-mono' as const,
    });
  }
  if (fonts.additional) {
    fontConfigs.push(...fonts.additional.map((font) => font as AstroFontConfigEntry));
  }
  return fontConfigs;
}
